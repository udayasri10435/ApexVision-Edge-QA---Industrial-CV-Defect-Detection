import { useState, useRef, useEffect } from 'react';
import { DefectItem, InspectionResult } from '../types/inspection';
import { Camera, ZoomIn, ZoomOut, Maximize2, Crosshair, Grid, Upload, Eye, EyeOff, CheckCircle2, AlertTriangle, XCircle, RefreshCw } from 'lucide-react';

interface VisionInspectionViewportProps {
  imageSrc: string;
  result: InspectionResult | null;
  selectedDefectId: string | null;
  onSelectDefect: (id: string | null) => void;
  isAnalyzing: boolean;
  onUploadImage: (file: File) => void;
  onCaptureWebcam: (dataUrl: string) => void;
}

export function VisionInspectionViewport({
  imageSrc,
  result,
  selectedDefectId,
  onSelectDefect,
  isAnalyzing,
  onUploadImage,
  onCaptureWebcam,
}: VisionInspectionViewportProps) {
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [showBoxes, setShowBoxes] = useState<boolean>(true);
  const [showGrid, setShowGrid] = useState<boolean>(false);
  const [showCrosshair, setShowCrosshair] = useState<boolean>(true);
  const [isWebcamActive, setIsWebcamActive] = useState<boolean>(false);
  const [hoveredBox, setHoveredBox] = useState<string | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Stop webcam stream when component unmounts or deactivated
  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop());
      }
    };
  }, []);

  const handleStartWebcam = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setIsWebcamActive(true);
    } catch (err) {
      console.error('Webcam access error:', err);
      alert('Camera access could not be acquired or is not supported in this frame.');
    }
  };

  const handleStopWebcam = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsWebcamActive(false);
  };

  const handleCaptureFrame = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 800;
    canvas.height = video.videoHeight || 600;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
    handleStopWebcam();
    onCaptureWebcam(dataUrl);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUploadImage(file);
    }
  };

  // Status visual cues
  const statusColor = result
    ? result.overallStatus === 'PASS'
      ? 'border-emerald-500 text-emerald-400 bg-emerald-950/40'
      : result.overallStatus === 'WARN'
      ? 'border-amber-500 text-amber-400 bg-amber-950/40'
      : 'border-rose-500 text-rose-400 bg-rose-950/40'
    : 'border-slate-700 text-slate-400 bg-slate-900/60';

  return (
    <div className="flex flex-col bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      {/* Viewport Control Bar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-slate-950/90 border-b border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 font-mono text-slate-300">
            <span className="inline-block w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            <span className="font-semibold tracking-wider uppercase">AOI CAM 01 // 4K HIGH RES</span>
          </div>
          <span className="text-slate-600">|</span>
          <span className="font-mono text-slate-400 tabular-nums">
            {result?.inspectionTimeMs ? `${result.inspectionTimeMs.toFixed(1)} ms latency` : 'READY'}
          </span>
        </div>

        {/* Viewport Action Controls */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowBoxes(!showBoxes)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded transition-colors ${
              showBoxes ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:bg-slate-800'
            }`}
            title="Toggle Defect Bounding Boxes"
          >
            {showBoxes ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>Boxes</span>
          </button>

          <button
            onClick={() => setShowGrid(!showGrid)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded transition-colors ${
              showGrid ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:bg-slate-800'
            }`}
            title="Toggle Spatial Inspection Grid"
          >
            <Grid className="w-3.5 h-3.5" />
            <span>Grid</span>
          </button>

          <button
            onClick={() => setShowCrosshair(!showCrosshair)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded transition-colors ${
              showCrosshair ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' : 'text-slate-400 hover:bg-slate-800'
            }`}
            title="Toggle Optical Center Crosshair"
          >
            <Crosshair className="w-3.5 h-3.5" />
            <span>Crosshair</span>
          </button>

          <div className="h-4 w-px bg-slate-800 mx-1" />

          {/* Zoom controls */}
          <button
            onClick={() => setZoomLevel((z) => Math.max(0.75, z - 0.25))}
            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <span className="font-mono text-slate-400 w-10 text-center">{Math.round(zoomLevel * 100)}%</span>
          <button
            onClick={() => setZoomLevel((z) => Math.min(3, z + 0.25))}
            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setZoomLevel(1)}
            className="p-1 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800"
            title="Reset Zoom"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>

          <div className="h-4 w-px bg-slate-800 mx-1" />

          {/* Upload and Webcam capture */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*"
            className="hidden"
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1 px-2.5 py-1 text-slate-300 hover:bg-slate-800 rounded transition-colors"
            title="Upload production line image or snapshot"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Image</span>
          </button>

          {!isWebcamActive ? (
            <button
              onClick={handleStartWebcam}
              className="flex items-center gap-1 px-2.5 py-1 bg-cyan-600/30 hover:bg-cyan-600/40 text-cyan-200 border border-cyan-500/40 rounded transition-colors"
              title="Activate live inspection camera stream"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Live Camera</span>
            </button>
          ) : (
            <div className="flex items-center gap-1">
              <button
                onClick={handleCaptureFrame}
                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-medium rounded transition-colors"
              >
                Snap Frame
              </button>
              <button
                onClick={handleStopWebcam}
                className="px-2 py-1 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Vision Stage */}
      <div
        ref={containerRef}
        className="relative w-full aspect-[4/3] bg-black overflow-hidden flex items-center justify-center select-none"
      >
        {/* Analyzing Overlay */}
        {isAnalyzing && (
          <div className="absolute inset-0 z-30 bg-slate-950/75 backdrop-blur-xs flex flex-col items-center justify-center gap-3">
            <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
            <div className="text-center font-mono">
              <p className="text-sm font-semibold text-cyan-300 tracking-wide">PROCESSING VISION INFERENCE</p>
              <p className="text-xs text-slate-400">Gemini 3.8 Flash · Spatial Bounding Box & Tolerancing</p>
            </div>
          </div>
        )}

        {/* Live Camera Feed if Active */}
        {isWebcamActive ? (
          <div className="relative w-full h-full flex items-center justify-center bg-black">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-contain"
            />
            <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1 bg-rose-950/80 border border-rose-500 text-rose-300 rounded text-xs font-mono">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              <span>LIVE CAM ACTIVE // CLICK 'SNAP FRAME' TO INSPECT</span>
            </div>
          </div>
        ) : (
          /* Static / Frame View with Zoom and Coordinate Overlays */
          <div
            className="relative transition-transform duration-150 ease-out origin-center flex items-center justify-center"
            style={{
              transform: `scale(${zoomLevel})`,
              width: '100%',
              height: '100%',
            }}
          >
            {/* The base subject image */}
            <img
              src={imageSrc}
              alt="Industrial Vision Inspection Target"
              referrerPolicy="no-referrer"
              className="max-w-full max-h-full object-contain pointer-events-none"
            />

            {/* Optical Center Crosshairs */}
            {showCrosshair && (
              <div className="absolute inset-0 pointer-events-none z-10">
                <div className="absolute left-1/2 top-0 bottom-0 w-px bg-cyan-400/25 -translate-x-1/2" />
                <div className="absolute top-1/2 left-0 right-0 h-px bg-cyan-400/25 -translate-y-1/2" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 rounded-full border border-cyan-400/30" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full border border-cyan-400/60" />
              </div>
            )}

            {/* Spatial Measurement Grid Overlay */}
            {showGrid && (
              <div
                className="absolute inset-0 pointer-events-none z-10"
                style={{
                  backgroundImage: `
                    linear-gradient(to right, rgba(56, 189, 248, 0.1) 1px, transparent 1px),
                    linear-gradient(to bottom, rgba(56, 189, 248, 0.1) 1px, transparent 1px)
                  `,
                  backgroundSize: '40px 40px',
                }}
              >
                <div className="absolute bottom-2 left-2 text-[10px] font-mono text-cyan-400/60 bg-slate-950/70 px-1.5 py-0.5 rounded">
                  CALIBRATION: 0.125 mm/px (TELECENTRIC OPTIC)
                </div>
              </div>
            )}

            {/* Bounding Box Defect Overlays */}
            {showBoxes && result?.defects && (
              <svg
                className="absolute inset-0 w-full h-full pointer-events-auto z-20"
                viewBox="0 0 1000 1000"
                preserveAspectRatio="none"
              >
                {result.defects.map((defect: DefectItem) => {
                  const [ymin, xmin, ymax, xmax] = defect.box_2d;
                  const width = Math.max(15, xmax - xmin);
                  const height = Math.max(15, ymax - ymin);
                  const isSelected = selectedDefectId === defect.id;
                  const isHovered = hoveredBox === defect.id;

                  const strokeColor =
                    defect.severity === 'CRITICAL'
                      ? '#ef4444'
                      : defect.severity === 'MAJOR'
                      ? '#f59e0b'
                      : '#38bdf8';

                  const fillColor =
                    defect.severity === 'CRITICAL'
                      ? 'rgba(239, 68, 68, 0.15)'
                      : defect.severity === 'MAJOR'
                      ? 'rgba(245, 158, 11, 0.12)'
                      : 'rgba(56, 189, 248, 0.1)';

                  return (
                    <g
                      key={defect.id}
                      className="cursor-pointer transition-all duration-150"
                      onClick={() => onSelectDefect(isSelected ? null : defect.id)}
                      onMouseEnter={() => setHoveredBox(defect.id)}
                      onMouseLeave={() => setHoveredBox(null)}
                    >
                      {/* Bounding Box Outline */}
                      <rect
                        x={xmin}
                        y={ymin}
                        width={width}
                        height={height}
                        fill={fillColor}
                        stroke={strokeColor}
                        strokeWidth={isSelected || isHovered ? 4 : 2}
                        strokeDasharray={isSelected ? 'none' : '6,3'}
                        className="transition-all"
                      />

                      {/* Corner Target Brackets for Industrial Machine Vision look */}
                      <g stroke={strokeColor} strokeWidth={3} fill="none">
                        {/* Top-Left */}
                        <path d={`M ${xmin} ${ymin + 12} L ${xmin} ${ymin} L ${xmin + 12} ${ymin}`} />
                        {/* Top-Right */}
                        <path d={`M ${xmin + width - 12} ${ymin} L ${xmin + width} ${ymin} L ${xmin + width} ${ymin + 12}`} />
                        {/* Bottom-Left */}
                        <path d={`M ${xmin} ${ymin + height - 12} L ${xmin} ${ymin + height} L ${xmin + 12} ${ymin + height}`} />
                        {/* Bottom-Right */}
                        <path d={`M ${xmin + width - 12} ${ymin + height} L ${xmin + width} ${ymin + height} L ${xmin + width} ${ymin + height - 12}`} />
                      </g>

                      {/* Header Label Tag on top of Box */}
                      <rect
                        x={xmin}
                        y={Math.max(0, ymin - 24)}
                        width={Math.min(300, Math.max(120, defect.label.length * 8 + 65))}
                        height={22}
                        fill={strokeColor}
                        rx={2}
                      />
                      <text
                        x={xmin + 6}
                        y={Math.max(15, ymin - 8)}
                        fill="#000000"
                        fontSize="13"
                        fontFamily="monospace"
                        fontWeight="bold"
                      >
                        {defect.label} · {(defect.confidence * 100).toFixed(0)}%
                      </text>
                    </g>
                  );
                })}
              </svg>
            )}
          </div>
        )}

        {/* Floating Quick Verdict Stamp */}
        {result && (
          <div className="absolute top-4 right-4 z-20 flex items-center gap-2">
            <div className={`px-3 py-1.5 border rounded-lg flex items-center gap-2 shadow-lg backdrop-blur-md ${statusColor}`}>
              {result.overallStatus === 'PASS' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
              {result.overallStatus === 'WARN' && <AlertTriangle className="w-4 h-4 text-amber-400" />}
              {result.overallStatus === 'FAIL' && <XCircle className="w-4 h-4 text-rose-400" />}
              <span className="font-mono font-bold text-sm tracking-wider">{result.overallStatus}</span>
              <span className="text-xs text-slate-300 font-mono">
                {result.qualityScore.toFixed(1)}/100
              </span>
            </div>
          </div>
        )}
      </div>

      {/* Viewport Footer Telemetry Bar */}
      <div className="flex items-center justify-between px-4 py-2 bg-slate-950 border-t border-slate-800 text-[11px] font-mono text-slate-400">
        <div className="flex items-center gap-4">
          <span>PIPELINE: EDGE-TENSORRT-INT8</span>
          <span>FPS: 48.4</span>
          <span>DEFECTS FOUND: <strong className="text-slate-200">{result?.defectCount ?? 0}</strong></span>
        </div>
        <div className="flex items-center gap-3">
          <span>ROUTING: <strong className="text-cyan-400">{result?.edgeAction?.conveyorRouting || 'PASS_FORWARD'}</strong></span>
          <span>DELAY: <strong className="text-slate-200">{result?.edgeAction?.strobeTriggerDelayMs || 35}ms</strong></span>
        </div>
      </div>
    </div>
  );
}
