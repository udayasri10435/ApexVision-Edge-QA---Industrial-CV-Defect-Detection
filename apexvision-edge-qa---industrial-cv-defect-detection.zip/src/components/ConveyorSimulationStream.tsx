import { useState, useEffect, useRef } from 'react';
import { DomainType } from '../types/inspection';
import { Play, Pause, Zap, RotateCcw, Sliders, CheckCircle2, XCircle, AlertOctagon } from 'lucide-react';

interface ConveyorItem {
  id: string;
  domain: DomainType;
  name: string;
  hasDefect: boolean;
  defectLabel?: string;
  positionX: number; // 0 to 100 percentage across belt
  inspected: boolean;
  status: 'PENDING' | 'PASS' | 'REJECT';
  ejected: boolean;
}

interface ConveyorSimulationStreamProps {
  currentDomain: DomainType;
}

export function ConveyorSimulationStream({ currentDomain }: ConveyorSimulationStreamProps) {
  const [isRunning, setIsRunning] = useState<boolean>(true);
  const [speedUnitsPerMin, setSpeedUnitsPerMin] = useState<number>(60);
  const [conveyorItems, setConveyorItems] = useState<ConveyorItem[]>([]);
  const [opticalStrobeActive, setOpticalStrobeActive] = useState<boolean>(false);
  const [pneumaticActive, setPneumaticActive] = useState<boolean>(false);
  
  // Real-time telemetry counters
  const [totalInspected, setTotalInspected] = useState<number>(142);
  const [passedCount, setPassedCount] = useState<number>(134);
  const [rejectedCount, setRejectedCount] = useState<number>(8);
  const [lastInferenceTimeMs, setLastInferenceTimeMs] = useState<number>(12.8);

  const requestRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(Date.now());
  const nextSpawnTimeRef = useRef<number>(Date.now());

  // Spawn new item on conveyor
  const spawnItem = (domain: DomainType): ConveyorItem => {
    const isDefect = Math.random() < 0.22; // ~22% defect rate for demonstration
    let name = 'PCB-Board-SMD';
    let defectLabel: string | undefined = undefined;

    if (domain === 'agriculture') {
      name = 'Honeycrisp Apple #78';
      defectLabel = isDefect ? 'Skin Russeting Lesion' : undefined;
    } else if (domain === 'logistics') {
      name = 'RSC Carton 40x30';
      defectLabel = isDefect ? 'Flute Crush Defect' : undefined;
    } else {
      defectLabel = isDefect ? 'SMT Solder Bridge' : undefined;
    }

    return {
      id: 'itm-' + Math.random().toString(36).substring(2, 9),
      domain,
      name,
      hasDefect: isDefect,
      defectLabel,
      positionX: 0,
      inspected: false,
      status: 'PENDING',
      ejected: false,
    };
  };

  useEffect(() => {
    // Reset initial items
    setConveyorItems([
      {
        id: 'init-1',
        domain: currentDomain,
        name: 'Initial Unit A',
        hasDefect: false,
        positionX: 65,
        inspected: true,
        status: 'PASS',
        ejected: false,
      },
      {
        id: 'init-2',
        domain: currentDomain,
        name: 'Initial Unit B',
        hasDefect: true,
        defectLabel: 'Porosity Anomaly',
        positionX: 30,
        inspected: false,
        status: 'PENDING',
        ejected: false,
      },
    ]);
  }, [currentDomain]);

  // Main conveyor physics & inspection loop
  useEffect(() => {
    const updateConveyor = () => {
      const now = Date.now();
      const deltaMs = now - lastTimeRef.current;
      lastTimeRef.current = now;

      if (isRunning) {
        // Calculate conveyor travel speed
        const speedPercentPerSecond = (speedUnitsPerMin / 60) * 20; // 20% travel per unit cadence
        const deltaPercent = (speedPercentPerSecond * deltaMs) / 1000;

        // Auto spawn items based on speed
        const spawnIntervalMs = (60 / speedUnitsPerMin) * 1800;
        if (now > nextSpawnTimeRef.current) {
          setConveyorItems((prev) => [...prev, spawnItem(currentDomain)]);
          nextSpawnTimeRef.current = now + spawnIntervalMs;
        }

        setConveyorItems((prevItems) => {
          return prevItems
            .map((item): ConveyorItem => {
              const newPos = item.positionX + deltaPercent;

              // Check if crossing optical inspection trigger zone (center ~48% - 52%)
              if (!item.inspected && newPos >= 48 && newPos <= 56) {
                // Trigger camera optical strobe
                setOpticalStrobeActive(true);
                setTimeout(() => setOpticalStrobeActive(false), 80);

                const latency = 11 + Math.random() * 5;
                setLastInferenceTimeMs(Number(latency.toFixed(1)));
                setTotalInspected((t) => t + 1);

                if (item.hasDefect) {
                  setRejectedCount((r) => r + 1);
                  // Trigger pneumatic reject pusher
                  setPneumaticActive(true);
                  setTimeout(() => setPneumaticActive(false), 220);

                  return {
                    ...item,
                    positionX: newPos,
                    inspected: true,
                    status: 'REJECT' as const,
                    ejected: true,
                  };
                } else {
                  setPassedCount((p) => p + 1);
                  return {
                    ...item,
                    positionX: newPos,
                    inspected: true,
                    status: 'PASS' as const,
                  };
                }
              }

              return {
                ...item,
                positionX: newPos,
              };
            })
            // Remove items once they roll past end (105%) or diverted
            .filter((item) => item.positionX < 105 && (!item.ejected || item.positionX < 65));
        });
      }

      requestRef.current = requestAnimationFrame(updateConveyor);
    };

    requestRef.current = requestAnimationFrame(updateConveyor);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [isRunning, speedUnitsPerMin, currentDomain]);

  const triggerManualStrobe = () => {
    setOpticalStrobeActive(true);
    setTimeout(() => setOpticalStrobeActive(false), 120);
  };

  const handleResetCounters = () => {
    setTotalInspected(0);
    setPassedCount(0);
    setRejectedCount(0);
  };

  const passRate = totalInspected > 0 ? ((passedCount / totalInspected) * 100).toFixed(1) : '100.0';
  const defectRate = totalInspected > 0 ? ((rejectedCount / totalInspected) * 100).toFixed(1) : '0.0';

  return (
    <div className="flex flex-col bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
      {/* Stream Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-950/90 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full ${isRunning ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
            <h3 className="text-sm font-semibold text-slate-100">Live Production Line Conveyor</h3>
          </div>
          <span className="text-xs text-slate-500 font-mono">· {currentDomain.toUpperCase()} LINE 01</span>
        </div>

        {/* Conveyor Controls */}
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-2 bg-slate-800/80 px-2.5 py-1 rounded border border-slate-700">
            <Sliders className="w-3.5 h-3.5 text-slate-400" />
            <span className="text-slate-300 font-mono">{speedUnitsPerMin} UPM</span>
            <input
              type="range"
              min="30"
              max="150"
              step="10"
              value={speedUnitsPerMin}
              onChange={(e) => setSpeedUnitsPerMin(Number(e.target.value))}
              className="w-16 accent-cyan-400 cursor-pointer"
            />
          </div>

          <button
            onClick={() => setIsRunning(!isRunning)}
            className={`flex items-center gap-1 px-3 py-1.5 rounded font-medium transition-colors ${
              isRunning ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30' : 'bg-emerald-600 text-white hover:bg-emerald-500'
            }`}
          >
            {isRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isRunning ? 'Pause Line' : 'Start Line'}</span>
          </button>

          <button
            onClick={triggerManualStrobe}
            className="flex items-center gap-1 px-2.5 py-1.5 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 rounded transition-colors"
            title="Manual Trigger Optical Strobe"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Force Strobe</span>
          </button>
        </div>
      </div>

      {/* Visual Simulation Conveyor Track */}
      <div className="relative h-64 bg-slate-950 overflow-hidden flex flex-col justify-center px-4">
        {/* Conveyor Frame Rails Top & Bottom */}
        <div className="absolute top-12 left-0 right-0 h-2 bg-slate-800 border-y border-slate-700" />
        <div className="absolute bottom-12 left-0 right-0 h-2 bg-slate-800 border-y border-slate-700" />

        {/* Conveyor Rollers / Textured Belt Background */}
        <div
          className="absolute top-14 bottom-14 left-0 right-0 bg-[#0d1525]"
          style={{
            backgroundImage: `repeating-linear-gradient(90deg, #131c31 0, #131c31 16px, #1a243d 16px, #1a243d 32px)`,
          }}
        />

        {/* Optical Sensor Gantry Inspection Station (Center 50%) */}
        <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-44 pointer-events-none z-20 flex flex-col items-center justify-between py-2">
          {/* Top Camera Gantry Head with Optical Strobe */}
          <div className={`flex flex-col items-center transition-all duration-75 ${opticalStrobeActive ? 'scale-105' : ''}`}>
            <div className={`px-2.5 py-0.5 rounded text-[10px] font-mono font-bold tracking-wider ${opticalStrobeActive ? 'bg-cyan-400 text-black shadow-lg shadow-cyan-400/50' : 'bg-slate-800 text-cyan-400 border border-slate-700'}`}>
              STROBE OPTIC
            </div>
            <div className={`w-8 h-4 bg-slate-700 rounded-b border-x border-b border-cyan-500/40 flex items-center justify-center ${opticalStrobeActive ? 'bg-cyan-200' : ''}`}>
              <div className={`w-3 h-3 rounded-full ${opticalStrobeActive ? 'bg-white shadow-[0_0_20px_#38bdf8]' : 'bg-cyan-500'}`} />
            </div>
          </div>

          {/* Strobe Light Beam Cone */}
          {opticalStrobeActive && (
            <div
              className="w-36 h-36 bg-cyan-400/20 blur-md pointer-events-none rounded-full animate-ping"
              style={{ animationDuration: '200ms' }}
            />
          )}

          {/* Optical Targeting Reticle */}
          <div className="w-32 h-28 border border-dashed border-cyan-400/40 rounded flex items-center justify-center">
            <div className="w-2 h-2 rounded-full bg-cyan-400/60" />
          </div>

          {/* Pneumatic Reject Pusher Arm at Bottom */}
          <div className="relative flex flex-col items-center">
            <div
              className={`w-6 h-10 bg-amber-500 rounded-t transition-transform duration-150 origin-bottom ${
                pneumaticActive ? 'translate-y-[-24px] scale-y-125 bg-rose-500' : 'translate-y-0'
              }`}
            />
            <span className="text-[9px] font-mono text-slate-500">PNEUMATIC EJECT</span>
          </div>
        </div>

        {/* Reject Chute Marker (at ~58% mark) */}
        <div className="absolute bottom-2 left-[56%] z-10 text-[10px] font-mono text-rose-400/80 bg-rose-950/60 px-2 py-0.5 rounded border border-rose-800/60">
          REJECT CHUTE ↓
        </div>

        {/* Conveyor Belt Direction Arrows */}
        <div className="absolute top-16 left-6 text-xs font-mono text-slate-600 flex items-center gap-1">
          <span>LINE FLOW</span>
          <span>→→→</span>
        </div>

        {/* Moving Items */}
        <div className="relative w-full h-28 z-10">
          {conveyorItems.map((item) => {
            return (
              <div
                key={item.id}
                className="absolute top-1/2 -translate-y-1/2 transition-transform duration-75"
                style={{
                  left: `${item.positionX}%`,
                  transform: item.ejected
                    ? 'translate(-50%, 50px) rotate(25deg)'
                    : 'translate(-50%, -50%)',
                  opacity: item.ejected ? 0.6 : 1,
                  transition: item.ejected ? 'all 0.25s ease-in' : 'none',
                }}
              >
                {/* Physical Item Graphic by Domain */}
                <div
                  className={`w-20 h-16 rounded-md border flex flex-col items-center justify-center p-1.5 shadow-md relative ${
                    item.status === 'PASS'
                      ? 'bg-slate-900 border-emerald-500/80 text-emerald-300'
                      : item.status === 'REJECT'
                      ? 'bg-rose-950/80 border-rose-500 text-rose-300'
                      : 'bg-slate-800/90 border-slate-700 text-slate-300'
                  }`}
                >
                  {/* Status Indicator Pip */}
                  {item.status === 'PASS' && (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 absolute top-1 right-1" />
                  )}
                  {item.status === 'REJECT' && (
                    <XCircle className="w-3.5 h-3.5 text-rose-400 absolute top-1 right-1 animate-pulse" />
                  )}

                  {/* Icon / Shape representation */}
                  {currentDomain === 'manufacturing' && (
                    <div className="w-10 h-7 bg-emerald-950/80 border border-emerald-600/40 rounded flex items-center justify-center">
                      <div className="w-4 h-4 bg-slate-900 border border-slate-600 rounded-xs" />
                    </div>
                  )}
                  {currentDomain === 'agriculture' && (
                    <div className="w-8 h-8 rounded-full bg-rose-600 border border-amber-600 flex items-center justify-center shadow-inner">
                      {item.hasDefect && <div className="w-2.5 h-2 bg-amber-950 rounded-full" />}
                    </div>
                  )}
                  {currentDomain === 'logistics' && (
                    <div className="w-12 h-8 bg-amber-800/70 border border-amber-600/60 rounded flex items-center justify-center">
                      <div className="w-5 h-2 bg-amber-500/30" />
                    </div>
                  )}

                  <span className="text-[9px] font-mono text-slate-300 truncate max-w-[70px] mt-1">
                    {item.hasDefect ? (item.defectLabel || 'Defect') : 'PASS'}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Production Telemetry Bar */}
      <div className="grid grid-cols-2 md:grid-cols-5 divide-x divide-slate-800 bg-slate-950 border-t border-slate-800 text-xs">
        <div className="p-3">
          <span className="text-slate-400 block text-[11px]">Total Inspected</span>
          <span className="font-mono text-lg font-bold text-slate-100 tabular-nums">{totalInspected}</span>
        </div>

        <div className="p-3">
          <span className="text-slate-400 block text-[11px]">First Pass Yield</span>
          <span className="font-mono text-lg font-bold text-emerald-400 tabular-nums">{passRate}%</span>
        </div>

        <div className="p-3">
          <span className="text-slate-400 block text-[11px]">Rejections (Ejected)</span>
          <span className="font-mono text-lg font-bold text-rose-400 tabular-nums">{rejectedCount}</span>
        </div>

        <div className="p-3">
          <span className="text-slate-400 block text-[11px]">Edge Latency</span>
          <span className="font-mono text-lg font-bold text-cyan-400 tabular-nums">{lastInferenceTimeMs} ms</span>
        </div>

        <div className="p-3 flex items-center justify-end">
          <button
            onClick={handleResetCounters}
            className="flex items-center gap-1 px-2.5 py-1 text-slate-400 hover:text-slate-200 text-xs rounded hover:bg-slate-800 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Counts</span>
          </button>
        </div>
      </div>
    </div>
  );
}
