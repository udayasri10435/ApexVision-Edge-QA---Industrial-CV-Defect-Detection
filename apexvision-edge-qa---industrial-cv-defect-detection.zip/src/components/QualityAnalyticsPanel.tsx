import { useState } from 'react';
import { AuditLogEntry, DomainType } from '../types/inspection';
import { BarChart3, Download, Search, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';

interface QualityAnalyticsPanelProps {
  auditLogs: AuditLogEntry[];
  currentDomain: DomainType;
}

export function QualityAnalyticsPanel({ auditLogs, currentDomain }: QualityAnalyticsPanelProps) {
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const paretoDefects = [
    { label: 'Solder Bridge Short', count: 48, percentage: 36, domain: 'manufacturing' },
    { label: 'Missing SMD Component', count: 32, percentage: 24, domain: 'manufacturing' },
    { label: 'Carton Flute Crush', count: 22, percentage: 17, domain: 'logistics' },
    { label: 'Compression Bruising', count: 18, percentage: 14, domain: 'agriculture' },
    { label: 'Surface Porosity / Micro-Crack', count: 12, percentage: 9, domain: 'manufacturing' },
  ];

  const filteredLogs = auditLogs.filter((log) => {
    const matchesStatus = filterStatus === 'ALL' || log.decision === filterStatus;
    const matchesSearch =
      log.batchId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.subjectTitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (log.primaryDefect && log.primaryDefect.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesStatus && matchesSearch;
  });

  const handleExportCSV = () => {
    const headers = ['Timestamp', 'Batch ID', 'Domain', 'Subject', 'Decision', 'Quality Score', 'Defects', 'Primary Defect', 'Latency (ms)', 'Conveyor Routing'];
    const rows = filteredLogs.map((log) => [
      log.timestamp,
      log.batchId,
      log.domain,
      `"${log.subjectTitle.replace(/"/g, '""')}"`,
      log.decision,
      log.qualityScore.toFixed(1),
      log.defectCount,
      `"${(log.primaryDefect || 'None').replace(/"/g, '""')}"`,
      log.latencyMs.toFixed(1),
      log.routing,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `qa-audit-log-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md">
          <span className="text-slate-400 text-xs block mb-1">First Pass Yield (FPY)</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-emerald-400 tabular-nums">98.4%</span>
            <span className="text-xs text-emerald-500 font-mono">+0.6% vs shift avg</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">ISO 9001 nominal target $\ge$ 98.0%</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md">
          <span className="text-slate-400 text-xs block mb-1">Mean Time Between Defects</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-cyan-400 tabular-nums">42.8 min</span>
            <span className="text-xs text-slate-400 font-mono">MTBD</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">Pneumatic reject arm nominal</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md">
          <span className="text-slate-400 text-xs block mb-1">Total Inspected Today</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-slate-100 tabular-nums">74,720</span>
            <span className="text-xs text-slate-400 font-mono">units</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">Across 3 active production lines</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-md">
          <span className="text-slate-400 text-xs block mb-1">Edge Decision Latency</span>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-cyan-300 tabular-nums">13.6 ms</span>
            <span className="text-xs text-emerald-400 font-mono">within 25ms budget</span>
          </div>
          <p className="text-[11px] text-slate-500 mt-2">Trigger-to-solenoid actuation</p>
        </div>
      </div>

      {/* Pareto Defect Distribution Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h4 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-cyan-400" />
              <span>Pareto Defect Class Distribution</span>
            </h4>
            <p className="text-xs text-slate-400">
              Root-cause frequency analysis identifying the 80/20 impact drivers across lines
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400">CURRENT SHIFT (8H)</span>
        </div>

        <div className="space-y-3">
          {paretoDefects.map((defect) => (
            <div key={defect.label} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-mono">{defect.label}</span>
                <span className="font-mono text-slate-400 tabular-nums">
                  {defect.count} occurrences · <strong className="text-slate-200">{defect.percentage}%</strong>
                </span>
              </div>
              <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                <div
                  className="h-full bg-cyan-500 transition-all duration-500"
                  style={{ width: `${defect.percentage * 2.5}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Audit History Log Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h4 className="text-sm font-semibold text-slate-100">Quality Inspection Audit Log</h4>
            <p className="text-xs text-slate-400">Individual unit pass/fail traces with edge actuator routing</p>
          </div>

          <div className="flex items-center gap-2">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter batch or defect..."
                className="bg-slate-900 border border-slate-700 text-slate-200 text-xs rounded-lg pl-8 pr-3 py-1.5 focus:outline-hidden focus:border-cyan-500 w-44"
              />
            </div>

            {/* Filter buttons - interactive buttons per frontend-design */}
            <div className="flex items-center p-0.5 bg-slate-900 rounded-lg border border-slate-800 text-xs">
              {(['ALL', 'PASS', 'WARN', 'FAIL'] as const).map((status) => (
                <button
                  key={status}
                  onClick={() => setFilterStatus(status)}
                  className={`px-2.5 py-1 font-medium rounded transition-colors ${
                    filterStatus === status
                      ? 'bg-slate-800 text-white shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>

            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Table Rows */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase font-mono text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-4 font-semibold">Timestamp</th>
                <th className="py-2.5 px-4 font-semibold">Batch ID</th>
                <th className="py-2.5 px-4 font-semibold">Subject / Line</th>
                <th className="py-2.5 px-4 font-semibold">Decision</th>
                <th className="py-2.5 px-4 font-semibold">Yield Score</th>
                <th className="py-2.5 px-4 font-semibold">Defect Detected</th>
                <th className="py-2.5 px-4 font-semibold">Latency</th>
                <th className="py-2.5 px-4 font-semibold">Conveyor Routing</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredLogs.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-500 font-mono">
                    No matching inspection logs found.
                  </td>
                </tr>
              ) : (
                filteredLogs.map((entry) => (
                  <tr key={entry.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-2.5 px-4 font-mono text-slate-400 tabular-nums">
                      {entry.timestamp}
                    </td>
                    <td className="py-2.5 px-4 font-mono font-medium text-slate-300">
                      {entry.batchId}
                    </td>
                    <td className="py-2.5 px-4 text-slate-200">
                      {entry.subjectTitle}
                    </td>
                    <td className="py-2.5 px-4">
                      {/* Clean unboxed text per zero-pill discipline */}
                      <span className={`font-mono font-bold flex items-center gap-1.5 ${
                        entry.decision === 'PASS'
                          ? 'text-emerald-400'
                          : entry.decision === 'WARN'
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}>
                        {entry.decision === 'PASS' && <CheckCircle2 className="w-3.5 h-3.5" />}
                        {entry.decision === 'WARN' && <AlertTriangle className="w-3.5 h-3.5" />}
                        {entry.decision === 'FAIL' && <XCircle className="w-3.5 h-3.5" />}
                        <span>{entry.decision}</span>
                      </span>
                    </td>
                    <td className="py-2.5 px-4 font-mono tabular-nums text-slate-200">
                      {entry.qualityScore.toFixed(1)}%
                    </td>
                    <td className="py-2.5 px-4 text-slate-300">
                      {entry.primaryDefect || <span className="text-slate-600">—</span>}
                    </td>
                    <td className="py-2.5 px-4 font-mono text-cyan-400 tabular-nums">
                      {entry.latencyMs.toFixed(1)} ms
                    </td>
                    <td className="py-2.5 px-4 font-mono text-slate-400 text-[11px]">
                      {entry.routing}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
