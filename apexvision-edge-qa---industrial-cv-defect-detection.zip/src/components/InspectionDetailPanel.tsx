import { InspectionResult, DefectItem } from '../types/inspection';
import { AlertCircle, CheckCircle2, AlertTriangle, ArrowRight, ShieldCheck, Wrench, Cpu, RefreshCw } from 'lucide-react';

interface InspectionDetailPanelProps {
  result: InspectionResult | null;
  selectedDefectId: string | null;
  onSelectDefect: (id: string | null) => void;
  onRunInspection: () => void;
  isAnalyzing: boolean;
  strictness: string;
  onChangeStrictness: (val: string) => void;
}

export function InspectionDetailPanel({
  result,
  selectedDefectId,
  onSelectDefect,
  onRunInspection,
  isAnalyzing,
  strictness,
  onChangeStrictness,
}: InspectionDetailPanelProps) {
  if (!result) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center text-center">
        <Cpu className="w-10 h-10 text-slate-600 mb-3" />
        <h4 className="text-sm font-semibold text-slate-300">Ready for Optical Quality Inspection</h4>
        <p className="text-xs text-slate-500 mt-1 max-w-xs">
          Select an inspection subject from presets, upload a line image, or activate live camera stream.
        </p>
        <button
          onClick={onRunInspection}
          disabled={isAnalyzing}
          className="mt-4 px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs rounded-lg transition-colors flex items-center gap-2"
        >
          {isAnalyzing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
          <span>Run Edge AI Inspection</span>
        </button>
      </div>
    );
  }

  const isPass = result.overallStatus === 'PASS';
  const isWarn = result.overallStatus === 'WARN';
  const isFail = result.overallStatus === 'FAIL';

  return (
    <div className="flex flex-col bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl divide-y divide-slate-800">
      {/* Header Verdict Card */}
      <div className="p-4 bg-slate-950/80">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {isPass && <CheckCircle2 className="w-7 h-7 text-emerald-400" />}
            {isWarn && <AlertTriangle className="w-7 h-7 text-amber-400" />}
            {isFail && <AlertCircle className="w-7 h-7 text-rose-500" />}
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base font-bold font-mono tracking-wide text-slate-100">
                  {result.overallStatus === 'PASS' && 'QUALITY VERIFIED: PASS'}
                  {result.overallStatus === 'WARN' && 'TOLERANCE WARNING: WARN'}
                  {result.overallStatus === 'FAIL' && 'CRITICAL DEFECT: REJECT'}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">{result.summary}</p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-slate-400 uppercase tracking-wider block">Quality Yield</span>
            <span className={`text-xl font-mono font-bold tabular-nums ${
              isPass ? 'text-emerald-400' : isWarn ? 'text-amber-400' : 'text-rose-400'
            }`}>
              {result.qualityScore.toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Quality Progress Meter */}
        <div className="mt-3 w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
          <div
            className={`h-full transition-all duration-500 ${
              isPass ? 'bg-emerald-500' : isWarn ? 'bg-amber-500' : 'bg-rose-500'
            }`}
            style={{ width: `${Math.min(100, Math.max(0, result.qualityScore))}%` }}
          />
        </div>
      </div>

      {/* Edge Actuator & Conveyor Routing Decision */}
      <div className="p-4 bg-slate-900/60">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            <span>PLC Edge Actuator Action</span>
          </span>
          <span className="text-[11px] font-mono text-slate-400">
            STROBE DELAY: {result.edgeAction.strobeTriggerDelayMs}ms
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded bg-slate-950/60 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Conveyor Route</span>
            <span className="font-mono font-semibold text-cyan-300">
              {result.edgeAction.conveyorRouting}
            </span>
          </div>
          <div className="p-2.5 rounded bg-slate-950/60 border border-slate-800 flex items-center justify-between">
            <span className="text-slate-400">Tolerance Tweak</span>
            <span className="font-mono text-slate-300 truncate max-w-[180px]" title={result.edgeAction.suggestedToleranceAdjustment}>
              {result.edgeAction.suggestedToleranceAdjustment}
            </span>
          </div>
        </div>
      </div>

      {/* Defect Localization List */}
      <div className="p-4 flex-1 overflow-y-auto max-h-[380px]">
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            Localized Defect Anomalies ({result.defects.length})
          </h4>
          <span className="text-[11px] text-slate-500">
            Click item to focus box on viewport
          </span>
        </div>

        {result.defects.length === 0 ? (
          <div className="py-6 text-center text-xs text-slate-400 bg-slate-950/40 rounded border border-dashed border-slate-800">
            <ShieldCheck className="w-8 h-8 text-emerald-400 mx-auto mb-2 opacity-80" />
            <p className="font-medium text-slate-300">Zero Defects Detected</p>
            <p className="text-[11px] text-slate-500 mt-0.5">Component conforms with engineering specifications.</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {result.defects.map((defect: DefectItem) => {
              const isSelected = selectedDefectId === defect.id;
              const severityColor =
                defect.severity === 'CRITICAL'
                  ? 'text-rose-400'
                  : defect.severity === 'MAJOR'
                  ? 'text-amber-400'
                  : 'text-cyan-400';

              return (
                <div
                  key={defect.id}
                  onClick={() => onSelectDefect(isSelected ? null : defect.id)}
                  className={`p-3 rounded-lg border text-xs cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-slate-800/90 border-cyan-500 shadow-md'
                      : 'bg-slate-950/50 border-slate-800 hover:border-slate-700 hover:bg-slate-800/40'
                  }`}
                >
                  {/* Clean unboxed metadata with typographic separators per zero-pill rules */}
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-semibold text-slate-200">{defect.label}</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className={`font-mono font-bold ${severityColor}`}>{defect.severity}</span>
                      <span aria-hidden="true" className="text-slate-600">·</span>
                      <span className="font-mono">{(defect.confidence * 100).toFixed(0)}% conf</span>
                    </div>
                    <span className="font-mono text-slate-500">{defect.id}</span>
                  </div>

                  <p className="text-slate-300 text-xs leading-relaxed">{defect.description}</p>

                  {defect.causeHypothesis && (
                    <div className="mt-2 text-[11px] text-slate-400 flex items-start gap-1.5">
                      <span className="text-slate-500 shrink-0 font-medium">Root Cause:</span>
                      <span className="text-slate-400">{defect.causeHypothesis}</span>
                    </div>
                  )}

                  <div className="mt-1.5 text-[11px] text-cyan-300/90 flex items-start gap-1.5 bg-cyan-950/30 p-1.5 rounded border border-cyan-900/40">
                    <Wrench className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                    <span>{defect.actionRecommendation}</span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Inspection Tuning Footer */}
      <div className="p-3 bg-slate-950 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <span className="text-slate-400 text-[11px]">Strictness Gate:</span>
          <select
            value={strictness}
            onChange={(e) => onChangeStrictness(e.target.value)}
            className="bg-slate-900 border border-slate-800 text-slate-200 text-xs rounded px-2 py-1 focus:outline-hidden focus:border-cyan-500"
          >
            <option value="standard">ISO 9001 Standard</option>
            <option value="aerospace_ipc_class3">IPC-A-610 Class 3 / Aerospace</option>
            <option value="high_speed_rough">High-Speed Rough Sorting</option>
          </select>
        </div>

        <button
          onClick={onRunInspection}
          disabled={isAnalyzing}
          className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-medium rounded flex items-center gap-1.5 transition-colors"
        >
          {isAnalyzing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
          <span>Re-inspect</span>
        </button>
      </div>
    </div>
  );
}
