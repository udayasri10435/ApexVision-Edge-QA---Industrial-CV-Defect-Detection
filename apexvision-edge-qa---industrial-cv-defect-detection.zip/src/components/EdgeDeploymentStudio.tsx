import { useState } from 'react';
import { EdgeNode } from '../types/inspection';
import { Cpu, Terminal, Download, Copy, Check, HardDrive, Zap, Radio, Server, CheckCircle2 } from 'lucide-react';

interface EdgeDeploymentStudioProps {
  edgeNodes: EdgeNode[];
}

export function EdgeDeploymentStudio({ edgeNodes }: EdgeDeploymentStudioProps) {
  const [selectedTarget, setSelectedTarget] = useState<'jetson_tensorrt' | 'coral_edgetpu' | 'intel_openvino'>('jetson_tensorrt');
  const [quantization, setQuantization] = useState<'INT8' | 'FP16' | 'FP32'>('INT8');
  const [activeCodeTab, setActiveCodeTab] = useState<'python' | 'docker' | 'manifest'>('python');
  const [copied, setCopied] = useState<boolean>(false);
  const [strobeGpioPin, setStrobeGpioPin] = useState<number>(18);
  const [ejectorGpioPin, setEjectorGpioPin] = useState<number>(23);
  const [confidenceCutoff, setConfidenceCutoff] = useState<number>(0.85);

  const pythonDaemonCode = `# ==============================================================================
# APEXVISION EDGE DAEMON - HIGH-SPEED PRODUCTION QUALITY INSPECTION
# Target Hardware: ${selectedTarget === 'jetson_tensorrt' ? 'NVIDIA Jetson Orin Nano (TensorRT)' : selectedTarget === 'coral_edgetpu' ? 'Google Coral Edge TPU (libedgetpu)' : 'Intel Industrial PC (OpenVINO)'}
# Precision: ${quantization} Quantized Engine
# ==============================================================================

import cv2
import numpy as np
import time
import json
import os

# Physical GPIO control for industrial optical strobe and pneumatic ejector
try:
    import RPi.GPIO as GPIO
    GPIO_AVAILABLE = True
except ImportError:
    GPIO_AVAILABLE = False
    print("[WARN] RPi.GPIO not found. Running in simulated dry-run mode.")

STROBE_PIN = ${strobeGpioPin}    # Camera flash strobe trigger
EJECTOR_PIN = ${ejectorGpioPin}  # Solenoid pneumatic diverter arm
CONFIDENCE_THRESHOLD = ${confidenceCutoff}

def initialize_gpio():
    if GPIO_AVAILABLE:
        GPIO.setmode(GPIO.BCM)
        GPIO.setup(STROBE_PIN, GPIO.OUT, initial=GPIO.LOW)
        GPIO.setup(EJECTOR_PIN, GPIO.OUT, initial=GPIO.LOW)
        print(f"[EDGE] Initialized GPIO Strobe: {STROBE_PIN}, Ejector: {EJECTOR_PIN}")

def trigger_actuator(pin, duration_ms):
    if GPIO_AVAILABLE:
        GPIO.output(pin, GPIO.HIGH)
        time.sleep(duration_ms / 1000.0)
        GPIO.output(pin, GPIO.LOW)

def run_edge_pipeline():
    initialize_gpio()
    print("[EDGE] Loading compiled ${quantization} model into local NPU accelerator...")
    
    # Initialize Industrial USB3/GigE Vision Camera (GenICam / V4L2)
    cap = cv2.VideoCapture(0, cv2.CAP_V4L2)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
    cap.set(cv2.CAP_PROP_FPS, 60)

    if not cap.isOpened():
        print("[ERROR] Cannot connect to Industrial Camera. Check USB/GigE interface.")
        return

    print("[EDGE] Pipeline active. Listening for optical encoder triggers...")

    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                continue

            t_start = time.perf_counter()

            # Pre-processing: Resize & Normalize to model input tensor
            input_tensor = cv2.resize(frame, (640, 640))
            input_tensor = cv2.cvtColor(input_tensor, cv2.COLOR_BGR2RGB)
            input_tensor = (input_tensor.astype(np.float32) / 255.0).transpose(2, 0, 1)
            input_tensor = np.expand_dims(input_tensor, axis=0)

            # --- Hardware Accelerated Inference (${selectedTarget.toUpperCase()}) ---
            # Simulated edge inference result from TensorRT engine
            t_infer = (time.perf_counter() - t_start) * 1000
            
            # Mock detection threshold evaluation
            defect_detected = False
            # If defect is found:
            if defect_detected:
                print(f"[REJECT] Defect detected! Latency: {t_infer:.2f}ms. Firing pneumatic ejector...")
                trigger_actuator(EJECTOR_PIN, duration_ms=45)
            else:
                pass # Pass forward

    except KeyboardInterrupt:
        print("[EDGE] Stopping pipeline...")
    finally:
        cap.release()
        if GPIO_AVAILABLE:
            GPIO.cleanup()

if __name__ == '__main__':
    run_edge_pipeline()
`;

  const dockerComposeCode = `version: '3.8'

services:
  apexvision-edge:
    image: apexvision/edge-runtime:2.4-${selectedTarget}
    container_name: edge-quality-agent
    restart: always
    network_mode: host
    privileged: true
    devices:
      - /dev/video0:/dev/video0
      - /dev/gpiomem:/dev/gpiomem
    environment:
      - INFERENCE_TARGET=${selectedTarget}
      - QUANTIZATION=${quantization}
      - STROBE_PIN=${strobeGpioPin}
      - EJECTOR_PIN=${ejectorGpioPin}
      - CONF_THRESHOLD=${confidenceCutoff}
      - MQTT_BROKER=mqtt://192.168.10.1:1883
    volumes:
      - ./models:/opt/apexvision/models
      - ./logs:/var/log/apexvision
    deploy:
      resources:
        reservations:
          devices:
            - driver: nvidia
              count: 1
              capabilities: [gpu]
`;

  const manifestJsonCode = JSON.stringify(
    {
      schemaVersion: '1.2.0',
      modelName: `apexvision-yolov8-industrial-${selectedTarget}-${quantization.toLowerCase()}`,
      exportedAt: new Date().toISOString(),
      targetPlatform: selectedTarget,
      precision: quantization,
      inputResolution: [640, 640, 3],
      inputMimeType: 'image/raw-rgb',
      meanNormalization: [0.485, 0.456, 0.406],
      stdNormalization: [0.229, 0.224, 0.225],
      nmsIouThreshold: 0.45,
      confidenceCutoff: confidenceCutoff,
      classes: [
        'solder_bridge',
        'missing_component',
        'tombstoning',
        'scratch_trace',
        'surface_porosity',
        'burr_lip',
        'skin_rot',
        'bruise_depression',
        'carton_crush',
        'barcode_damage',
      ],
      gpioConfig: {
        opticalStrobePin: strobeGpioPin,
        pneumaticEjectorPin: ejectorGpioPin,
        solenoidPulseMs: 45,
      },
    },
    null,
    2
  );

  const handleCopyCode = () => {
    let text = pythonDaemonCode;
    if (activeCodeTab === 'docker') text = dockerComposeCode;
    if (activeCodeTab === 'manifest') text = manifestJsonCode;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadBundle = () => {
    const bundleContent = JSON.stringify(
      {
        target: selectedTarget,
        quantization,
        manifest: JSON.parse(manifestJsonCode),
        pythonScript: pythonDaemonCode,
        dockerCompose: dockerComposeCode,
      },
      null,
      2
    );

    const blob = new Blob([bundleContent], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `edge-deployment-${selectedTarget}-${quantization.toLowerCase()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Edge Fleet Nodes Telemetry Cards */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Server className="w-4 h-4 text-cyan-400" />
              <span>Active Edge Gateway Fleet</span>
            </h3>
            <p className="text-xs text-slate-400">
              Low-latency edge nodes deployed directly adjacent to physical conveyor lines
            </p>
          </div>
          <span className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>3 OF 3 NODES SYNCED</span>
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {edgeNodes.map((node) => (
            <div
              key={node.id}
              className="bg-slate-900 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-slate-700 transition-all shadow-md"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono text-xs font-semibold text-slate-200 truncate">
                    {node.name}
                  </span>
                  <span className="text-[10px] font-mono font-bold text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>{node.status}</span>
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 my-3 text-[11px] font-mono text-slate-300">
                  <div className="p-2 rounded bg-slate-950/70 border border-slate-800/80">
                    <span className="text-slate-500 block text-[10px]">INFERENCE</span>
                    <span className="text-cyan-300 font-bold tabular-nums">{node.inferenceLatencyMs} ms</span>
                  </div>
                  <div className="p-2 rounded bg-slate-950/70 border border-slate-800/80">
                    <span className="text-slate-500 block text-[10px]">TEMP / LOAD</span>
                    <span className="text-amber-300 font-bold tabular-nums">
                      {node.temperatureC}°C · {node.gpuUtilizationPct}%
                    </span>
                  </div>
                  <div className="p-2 rounded bg-slate-950/70 border border-slate-800/80">
                    <span className="text-slate-500 block text-[10px]">TODAY'S UNITS</span>
                    <span className="text-slate-200 font-bold tabular-nums">{node.inspectedCountToday.toLocaleString()}</span>
                  </div>
                  <div className="p-2 rounded bg-slate-950/70 border border-slate-800/80">
                    <span className="text-slate-500 block text-[10px]">YIELD (FPY)</span>
                    <span className="text-emerald-400 font-bold tabular-nums">{node.fpyPercentage}%</span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-500">
                <span>IP: {node.ipAddress}</span>
                <span>FW: {node.firmware}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Model Export & Configuration Studio */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h4 className="text-sm font-semibold text-slate-100 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span>Edge Model Compiler & Deployment Configurator</span>
            </h4>
            <p className="text-xs text-slate-400">
              Compile inspection weights into optimized runtime formats for on-premise industrial gateways
            </p>
          </div>

          <button
            onClick={handleDownloadBundle}
            className="px-3.5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
          >
            <Download className="w-4 h-4" />
            <span>Export Edge Bundle (.json)</span>
          </button>
        </div>

        {/* Configuration Parameters Form */}
        <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 border-b border-slate-800 text-xs">
          <div>
            <label className="text-slate-400 block mb-1.5 font-medium">Target Edge Accelerator</label>
            <select
              value={selectedTarget}
              onChange={(e) => setSelectedTarget(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-700 rounded-md px-3 py-2 text-slate-200 focus:outline-hidden focus:border-cyan-500"
            >
              <option value="jetson_tensorrt">NVIDIA Jetson (TensorRT FP16/INT8)</option>
              <option value="coral_edgetpu">Google Coral TPU (EdgeTPU TFLite)</option>
              <option value="intel_openvino">Intel IPC-610 (OpenVINO)</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1.5 font-medium">Model Precision Quantization</label>
            <div className="grid grid-cols-3 gap-1 p-1 bg-slate-950 rounded-md border border-slate-800">
              {(['INT8', 'FP16', 'FP32'] as const).map((q) => (
                <button
                  key={q}
                  onClick={() => setQuantization(q)}
                  className={`py-1 text-center font-mono font-medium rounded transition-colors ${
                    quantization === q ? 'bg-cyan-600 text-white shadow-xs' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-slate-400 block mb-1.5 font-medium">
              Confidence Cutoff: <span className="text-cyan-400 font-mono">{(confidenceCutoff * 100).toFixed(0)}%</span>
            </label>
            <input
              type="range"
              min="0.5"
              max="0.99"
              step="0.01"
              value={confidenceCutoff}
              onChange={(e) => setConfidenceCutoff(Number(e.target.value))}
              className="w-full accent-cyan-400 mt-2 cursor-pointer"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1.5 font-medium">GPIO Hardware Pins (BCM)</label>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 bg-slate-950 border border-slate-700 px-2 py-1.5 rounded w-1/2">
                <span className="text-[10px] text-slate-500">Strobe:</span>
                <input
                  type="number"
                  value={strobeGpioPin}
                  onChange={(e) => setStrobeGpioPin(Number(e.target.value))}
                  className="w-full bg-transparent text-slate-200 font-mono text-xs focus:outline-hidden"
                />
              </div>
              <div className="flex items-center gap-1 bg-slate-950 border border-slate-700 px-2 py-1.5 rounded w-1/2">
                <span className="text-[10px] text-slate-500">Eject:</span>
                <input
                  type="number"
                  value={ejectorGpioPin}
                  onChange={(e) => setEjectorGpioPin(Number(e.target.value))}
                  className="w-full bg-transparent text-slate-200 font-mono text-xs focus:outline-hidden"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Code Snippet Tabs */}
        <div className="flex items-center justify-between px-4 pt-3 bg-slate-950 border-b border-slate-800 text-xs">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveCodeTab('python')}
              className={`px-3 py-1.5 font-medium rounded-t-md border-t border-x transition-colors ${
                activeCodeTab === 'python'
                  ? 'bg-slate-900 border-slate-700 text-cyan-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              edge_daemon.py
            </button>
            <button
              onClick={() => setActiveCodeTab('docker')}
              className={`px-3 py-1.5 font-medium rounded-t-md border-t border-x transition-colors ${
                activeCodeTab === 'docker'
                  ? 'bg-slate-900 border-slate-700 text-cyan-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              docker-compose.yml
            </button>
            <button
              onClick={() => setActiveCodeTab('manifest')}
              className={`px-3 py-1.5 font-medium rounded-t-md border-t border-x transition-colors ${
                activeCodeTab === 'manifest'
                  ? 'bg-slate-900 border-slate-700 text-cyan-300'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              model_manifest.json
            </button>
          </div>

          <button
            onClick={handleCopyCode}
            className="flex items-center gap-1 text-slate-400 hover:text-slate-200 text-xs px-2.5 py-1 rounded hover:bg-slate-800 transition-colors"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied to Clipboard' : 'Copy File'}</span>
          </button>
        </div>

        {/* Code View Area */}
        <div className="p-4 bg-slate-950 font-mono text-xs overflow-x-auto max-h-96 text-slate-300 leading-relaxed selection:bg-cyan-500/30">
          <pre>
            {activeCodeTab === 'python' && pythonDaemonCode}
            {activeCodeTab === 'docker' && dockerComposeCode}
            {activeCodeTab === 'manifest' && manifestJsonCode}
          </pre>
        </div>
      </div>
    </div>
  );
}
