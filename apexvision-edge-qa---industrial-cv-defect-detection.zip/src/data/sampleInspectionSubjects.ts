import { SampleSubject } from '../types/inspection';

// Helper to convert SVG markup into a clean data URI
function svgToDataUri(svgContent: string): string {
  const encoded = encodeURIComponent(svgContent.trim())
    .replace(/'/g, '%27')
    .replace(/"/g, '%22');
  return `data:image/svg+xml;charset=utf-8,${encoded}`;
}

export const SAMPLE_SUBJECTS: SampleSubject[] = [
  // --- MANUFACTURING ---
  {
    id: 'mfg-pcb-01',
    title: 'High-Density SMT Circuit Board (IC & SMD Passives)',
    domain: 'manufacturing',
    subCategory: 'Electronics & SMT',
    itemType: 'SMD Circuit Board REV 4.2',
    description: 'Automated Optical Inspection (AOI) capture of QFP-48 micro-controller footprint and surrounding decoupling capacitors.',
    svgDataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600" style="background:#062615;">
        <defs>
          <pattern id="pcbGrid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M 20 0 L 0 0 0 20" fill="none" stroke="#0a3d24" stroke-width="1"/>
          </pattern>
          <linearGradient id="icGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#1e2227" />
            <stop offset="100%" stop-color="#0f1115" />
          </linearGradient>
          <linearGradient id="goldTrace" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stop-color="#d4af37" />
            <stop offset="50%" stop-color="#f9e27c" />
            <stop offset="100%" stop-color="#c59b27" />
          </linearGradient>
        </defs>
        <rect width="800" height="600" fill="url(#pcbGrid)"/>
        
        <!-- Copper Traces -->
        <path d="M 50 150 L 250 150 L 320 220 L 320 300" stroke="url(#goldTrace)" stroke-width="5" fill="none"/>
        <path d="M 50 180 L 230 180 L 300 250 L 300 320" stroke="url(#goldTrace)" stroke-width="4" fill="none"/>
        <path d="M 750 450 L 550 450 L 480 380 L 480 300" stroke="url(#goldTrace)" stroke-width="5" fill="none"/>
        <path d="M 750 420 L 570 420 L 500 350 L 500 280" stroke="url(#goldTrace)" stroke-width="4" fill="none"/>
        
        <!-- Ground Plane Areas -->
        <rect x="60" y="380" width="180" height="150" rx="6" fill="#0d4a2c" stroke="#17633d" stroke-width="2"/>
        <text x="75" y="410" fill="#2fd180" font-family="monospace" font-size="14" font-weight="bold">GND PLANE #2</text>
        
        <!-- Scratched trace anomaly (Defect 3) -->
        <path d="M 80 440 L 210 440" stroke="#d4af37" stroke-width="4"/>
        <!-- Scratch gouge -->
        <path d="M 130 425 L 160 460" stroke="#f43f5e" stroke-width="3" stroke-linecap="round"/>
        <circle cx="145" cy="442" r="16" fill="none" stroke="#f43f5e" stroke-width="1.5" stroke-dasharray="3,3"/>
        
        <!-- Main IC Package (QFP-48) Centered -->
        <rect x="330" y="230" width="140" height="140" rx="8" fill="url(#icGrad)" stroke="#374151" stroke-width="3"/>
        <circle cx="350" cy="250" r="4" fill="#6b7280"/>
        <text x="355" y="305" fill="#9ca3af" font-family="monospace" font-size="13" font-weight="bold" letter-spacing="1">ARM STM32</text>
        <text x="355" y="325" fill="#6b7280" font-family="monospace" font-size="10">F407VGT6</text>
        
        <!-- IC Pins Left -->
        <g fill="#d1d5db" stroke="#9ca3af" stroke-width="1">
          <rect x="295" y="245" width="30" height="6"/>
          <rect x="295" y="260" width="30" height="6"/>
          <rect x="295" y="275" width="30" height="6"/>
          <rect x="295" y="290" width="30" height="6"/>
          <!-- DEFECT 1: Solder Bridge between pins 290 and 305 -->
          <rect x="295" y="305" width="30" height="6"/>
          <rect x="295" y="320" width="30" height="6"/>
          <path d="M 310 288 Q 324 300 310 312 Z" fill="#94a3b8" stroke="#cbd5e1" stroke-width="2"/>
        </g>
        
        <!-- IC Pins Right -->
        <g fill="#d1d5db" stroke="#9ca3af" stroke-width="1">
          <rect x="475" y="245" width="30" height="6"/>
          <rect x="475" y="260" width="30" height="6"/>
          <rect x="475" y="275" width="30" height="6"/>
          <rect x="475" y="290" width="30" height="6"/>
          <rect x="475" y="305" width="30" height="6"/>
          <rect x="475" y="320" width="30" height="6"/>
        </g>
        
        <!-- IC Pins Top & Bottom -->
        <g fill="#d1d5db">
          <rect x="355" y="195" width="6" height="30"/>
          <rect x="375" y="195" width="6" height="30"/>
          <rect x="395" y="195" width="6" height="30"/>
          <rect x="415" y="195" width="6" height="30"/>
          <rect x="435" y="195" width="6" height="30"/>
          
          <rect x="355" y="375" width="6" height="30"/>
          <rect x="375" y="375" width="6" height="30"/>
          <rect x="395" y="375" width="6" height="30"/>
          <rect x="415" y="375" width="6" height="30"/>
          <rect x="435" y="375" width="6" height="30"/>
        </g>

        <!-- SMD Decoupling Capacitors (0603 size) Top-Right -->
        <!-- Normal Cap C21 -->
        <rect x="540" y="170" width="18" height="34" rx="2" fill="#8d5b4c" stroke="#e2e8f0" stroke-width="3"/>
        <text x="540" y="160" fill="#94a3b8" font-family="monospace" font-size="10">C21</text>
        
        <!-- Normal Cap C22 -->
        <rect x="575" y="170" width="18" height="34" rx="2" fill="#8d5b4c" stroke="#e2e8f0" stroke-width="3"/>
        <text x="575" y="160" fill="#94a3b8" font-family="monospace" font-size="10">C22</text>
        
        <!-- DEFECT 2: MISSING CAP C24 (Empty bare solder pads) -->
        <rect x="610" y="166" width="18" height="10" fill="#cbd5e1" stroke="#94a3b8" stroke-width="1"/>
        <rect x="610" y="198" width="18" height="10" fill="#cbd5e1" stroke="#94a3b8" stroke-width="1"/>
        <rect x="608" y="164" width="22" height="46" fill="none" stroke="#f59e0b" stroke-width="2" stroke-dasharray="4,3"/>
        <text x="605" y="155" fill="#f59e0b" font-family="monospace" font-size="11" font-weight="bold">C24 [EMPTY]</text>
        
        <!-- Fiducial Target Alignment Marker -->
        <circle cx="100" cy="80" r="14" fill="#0d4a2c" stroke="#22c55e" stroke-width="2"/>
        <circle cx="100" cy="80" r="5" fill="#d4af37"/>
        <text x="125" y="85" fill="#22c55e" font-family="monospace" font-size="11">FID_01 OK</text>
        
        <circle cx="700" cy="520" r="14" fill="#0d4a2c" stroke="#22c55e" stroke-width="2"/>
        <circle cx="700" cy="520" r="5" fill="#d4af37"/>
        <text x="620" y="525" fill="#22c55e" font-family="monospace" font-size="11">FID_02 OK</text>
      </svg>
    `),
    defaultResult: {
      overallStatus: 'FAIL',
      qualityScore: 58.0,
      defectCount: 2,
      summary: 'SMT Optical Inspection Gate Rejected: Solder bridging detected on IC pins 14-15 and missing C24 decoupling capacitor.',
      inspectionTimeMs: 14.8,
      defects: [
        {
          id: 'DEF-SMT-01',
          label: 'Solder Bridge Short',
          confidence: 0.98,
          severity: 'CRITICAL',
          box_2d: [465, 360, 530, 420],
          description: 'Unintended metallic solder joint shorting IC pins 14 & 15 causing ground-to-VCC fault.',
          causeHypothesis: 'Excessive solder paste deposition from stencil aperture wear or squeegee over-pressure.',
          actionRecommendation: 'Divert PCB to Rework Chute 2; alert line engineer to inspect SMT stencil aperture #4.',
        },
        {
          id: 'DEF-SMT-02',
          label: 'Missing Component (C24)',
          confidence: 0.94,
          severity: 'MAJOR',
          box_2d: [265, 755, 360, 805],
          description: 'Bare unpopulated solder pads at capacitor designator C24.',
          causeHypothesis: 'SMT feeder reel vacuum nozzle mis-pick or component tape pocket misalignment.',
          actionRecommendation: 'Check pick-and-place nozzle #3 vacuum sensor threshold.',
        },
      ],
      edgeAction: {
        conveyorRouting: 'REJECT_PNEUMATIC_PUSHER',
        strobeTriggerDelayMs: 38,
        suggestedToleranceAdjustment: 'Increase AOI solder bridge sensitivity cutoff to 0.92',
      },
      processedBy: 'gemini-3.8-flash-edge-gateway',
      timestamp: '2026-09-29T08:30:12Z',
    },
  },
  {
    id: 'mfg-flange-02',
    title: 'CNC Machined Titanium Flange (Bore & Sealing Surface)',
    domain: 'manufacturing',
    subCategory: 'Precision Machining',
    itemType: 'Ti-6Al-4V Aerospace Flange',
    description: 'High-magnification telecentric lens inspection of CNC turned gasket sealing surface and inner bore chamfer.',
    svgDataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600" style="background:#090d16;">
        <defs>
          <radialGradient id="metalRing" cx="50%" cy="50%" r="50%">
            <stop offset="30%" stop-color="#1e293b"/>
            <stop offset="65%" stop-color="#475569"/>
            <stop offset="85%" stop-color="#94a3b8"/>
            <stop offset="100%" stop-color="#334155"/>
          </radialGradient>
        </defs>
        <!-- Outer Flange Disc -->
        <circle cx="400" cy="300" r="240" fill="url(#metalRing)" stroke="#cbd5e1" stroke-width="4"/>
        <circle cx="400" cy="300" r="210" fill="none" stroke="#64748b" stroke-width="1.5" stroke-dasharray="2,4"/>
        <circle cx="400" cy="300" r="170" fill="none" stroke="#94a3b8" stroke-width="2"/>
        
        <!-- Inner Bore -->
        <circle cx="400" cy="300" r="90" fill="#030712" stroke="#e2e8f0" stroke-width="4"/>
        
        <!-- Bolt Holes -->
        <circle cx="400" cy="110" r="18" fill="#030712" stroke="#64748b" stroke-width="2"/>
        <circle cx="400" cy="490" r="18" fill="#030712" stroke="#64748b" stroke-width="2"/>
        <circle cx="210" cy="300" r="18" fill="#030712" stroke="#64748b" stroke-width="2"/>
        <circle cx="590" cy="300" r="18" fill="#030712" stroke="#64748b" stroke-width="2"/>
        <circle cx="265" cy="165" r="18" fill="#030712" stroke="#64748b" stroke-width="2"/>
        <circle cx="535" cy="435" r="18" fill="#030712" stroke="#64748b" stroke-width="2"/>
        <circle cx="265" cy="435" r="18" fill="#030712" stroke="#64748b" stroke-width="2"/>
        <circle cx="535" cy="165" r="18" fill="#030712" stroke="#64748b" stroke-width="2"/>
        
        <!-- DEFECT: Radial Stress Micro-Crack on sealing lip -->
        <path d="M 400 210 L 404 185 L 398 165 L 402 145" stroke="#ef4444" stroke-width="3" fill="none"/>
        
        <!-- DEFECT: Edge Burr around Bolt Hole at 210, 300 -->
        <path d="M 226 290 Q 235 300 226 310" stroke="#f59e0b" stroke-width="4" fill="none"/>
        
        <text x="35" y="50" fill="#38bdf8" font-family="monospace" font-size="14" font-weight="bold">TELECENTRIC INSPECTION: CAM_03</text>
        <text x="35" y="75" fill="#94a3b8" font-family="monospace" font-size="12">SUBJECT: FLANGE_TI64_240MM</text>
      </svg>
    `),
    defaultResult: {
      overallStatus: 'FAIL',
      qualityScore: 64.2,
      defectCount: 2,
      summary: 'Radial micro-fracture detected across primary sealing face, exceeding aerospace leak-rate tolerance.',
      inspectionTimeMs: 16.4,
      defects: [
        {
          id: 'DEF-CNC-01',
          label: 'Radial Stress Micro-Crack',
          confidence: 0.96,
          severity: 'CRITICAL',
          box_2d: [230, 485, 360, 520],
          description: 'Continuous 1.8mm fatigue crack running through critical O-ring sealing land.',
          causeHypothesis: 'Thermal shock during CNC cooling cycle or tungsten carbide tool chatter.',
          actionRecommendation: 'Eject part to Scrap Hopper; replace CNC turning insert on tool station #4.',
        },
        {
          id: 'DEF-CNC-02',
          label: 'Machining Burr / Flange Lip',
          confidence: 0.89,
          severity: 'MINOR',
          box_2d: [470, 255, 530, 305],
          description: 'Un-deburred metal lip extending 0.4mm into bolt through-hole chamfer.',
          causeHypothesis: 'Worn chamfer milling tool.',
          actionRecommendation: 'Send for secondary automated deburring brush pass.',
        },
      ],
      edgeAction: {
        conveyorRouting: 'REJECT_PNEUMATIC_PUSHER',
        strobeTriggerDelayMs: 44,
        suggestedToleranceAdjustment: 'Adjust tool wear compensation offset by -0.015mm on X-axis',
      },
      processedBy: 'gemini-3.8-flash-edge-gateway',
      timestamp: '2026-09-29T08:34:40Z',
    },
  },

  // --- AGRICULTURE ---
  {
    id: 'ag-apple-01',
    title: 'Honeycrisp Apples Sorting Conveyor (Multi-Lane Optical)',
    domain: 'agriculture',
    subCategory: 'Fresh Fruit Packaging',
    itemType: 'Honeycrisp Apple (Diameter 78mm)',
    description: 'Overhead hyperspectral & RGB camera view on rotating roller conveyor sorting for fresh commercial export.',
    svgDataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600" style="background:#131822;">
        <!-- Stainless steel conveyor rollers -->
        <rect x="50" y="40" width="700" height="15" fill="#334155" rx="3"/>
        <rect x="50" y="160" width="700" height="15" fill="#334155" rx="3"/>
        <rect x="50" y="280" width="700" height="15" fill="#334155" rx="3"/>
        <rect x="50" y="400" width="700" height="15" fill="#334155" rx="3"/>
        <rect x="50" y="520" width="700" height="15" fill="#334155" rx="3"/>
        
        <!-- Lane Dividers -->
        <line x1="280" y1="20" x2="280" y2="580" stroke="#1e293b" stroke-width="4"/>
        <line x1="520" y1="20" x2="520" y2="580" stroke="#1e293b" stroke-width="4"/>
        
        <!-- Apple 1 (Lane 1, Top) - Grade A -->
        <g transform="translate(170, 100)">
          <ellipse cx="0" cy="0" rx="55" ry="50" fill="#dc2626"/>
          <path d="M -50 -10 Q 0 45 45 -10 Q 0 -45 -50 -10 Z" fill="#ef4444" opacity="0.4"/>
          <!-- Stem -->
          <path d="M 0 -48 Q 10 -65 2 -70" stroke="#78350f" stroke-width="3" fill="none"/>
          <text x="-35" y="70" fill="#22c55e" font-family="monospace" font-size="11">LANE 1: GRADE A</text>
        </g>
        
        <!-- Apple 2 (Lane 2, Center) - DEFECTIVE SAMPLE -->
        <g transform="translate(400, 220)">
          <ellipse cx="0" cy="0" rx="65" ry="60" fill="#b91c1c"/>
          <path d="M -60 -10 Q 0 55 55 -10 Q 0 -55 -60 -10 Z" fill="#dc2626" opacity="0.5"/>
          <path d="M 0 -58 Q 8 -75 0 -80" stroke="#78350f" stroke-width="4" fill="none"/>
          
          <!-- Defect 1: Mechanical Compression Bruise -->
          <ellipse cx="-25" cy="15" rx="22" ry="18" fill="#451a03" opacity="0.85"/>
          
          <!-- Defect 2: Fungal Russeting & Scab Spot -->
          <circle cx="28" cy="-20" r="10" fill="#713f12" stroke="#a16207" stroke-width="2"/>
          <circle cx="34" cy="-12" r="5" fill="#713f12"/>
          
          <text x="-45" y="85" fill="#f43f5e" font-family="monospace" font-size="11" font-weight="bold">LANE 2: REJECT/JUICE</text>
        </g>
        
        <!-- Apple 3 (Lane 3, Lower) - Grade A -->
        <g transform="translate(630, 340)">
          <ellipse cx="0" cy="0" rx="58" ry="54" fill="#ea580c"/>
          <path d="M -50 -10 Q 0 48 48 -10 Q 0 -48 -50 -10 Z" fill="#f97316" opacity="0.4"/>
          <path d="M 0 -52 Q 10 -68 4 -72" stroke="#78350f" stroke-width="3" fill="none"/>
          <text x="-35" y="70" fill="#22c55e" font-family="monospace" font-size="11">LANE 3: GRADE A</text>
        </g>
        
        <text x="35" y="40" fill="#38bdf8" font-family="monospace" font-size="13" font-weight="bold">OPTICAL PACKHOUSE GRADER #04</text>
      </svg>
    `),
    defaultResult: {
      overallStatus: 'FAIL',
      qualityScore: 52.6,
      defectCount: 2,
      summary: 'Grade Reject: Severe mechanical compression bruising (>20mm) and localized apple scab fungal lesion.',
      inspectionTimeMs: 12.3,
      defects: [
        {
          id: 'DEF-AG-01',
          label: 'Deep Compression Bruise',
          confidence: 0.97,
          severity: 'CRITICAL',
          box_2d: [310, 440, 430, 530],
          description: 'Darkened tissue depression 24mm in diameter causing sub-epidermal softening.',
          causeHypothesis: 'Excessive drop impact on dumper conveyor transfer chute.',
          actionRecommendation: 'Activate air-jet reject nozzle #2 to divert fruit into industrial cider puree bin.',
        },
        {
          id: 'DEF-AG-02',
          label: 'Apple Scab (Venturia inaequalis)',
          confidence: 0.91,
          severity: 'MAJOR',
          box_2d: [275, 520, 360, 575],
          description: 'Epidermal fungal crust lesion with corky margin.',
          causeHypothesis: 'Humid microclimate conditions in orchard block 12.',
          actionRecommendation: 'Log orchard geolocation tag for targeted post-harvest antifungal rinse.',
        },
      ],
      edgeAction: {
        conveyorRouting: 'REJECT_PNEUMATIC_PUSHER',
        strobeTriggerDelayMs: 25,
        suggestedToleranceAdjustment: 'Set optical color sorter blemish cutoff to <5% surface area',
      },
      processedBy: 'gemini-3.8-flash-edge-gateway',
      timestamp: '2026-09-29T08:38:05Z',
    },
  },
  {
    id: 'ag-citrus-02',
    title: 'Export Citrus & Lemon Rind Integrity',
    domain: 'agriculture',
    subCategory: 'Citrus Packing',
    itemType: 'Eureka Lemon (Class 1 Export)',
    description: 'High-speed line inspection for oleocellosis oil gland ruptures, stem mold, and thrips scar.',
    svgDataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600" style="background:#0f172a;">
        <!-- Conveyor Background -->
        <rect x="100" y="80" width="600" height="440" fill="#1e293b" rx="12" stroke="#334155" stroke-width="2"/>
        
        <!-- Lemon Body -->
        <g transform="translate(400, 300)">
          <!-- Oval shape with pointed ends -->
          <path d="M -160 0 Q -170 -120 0 -130 Q 170 -120 180 0 Q 170 120 0 130 Q -170 120 -160 0 Z" fill="#eab308" stroke="#ca8a04" stroke-width="3"/>
          <ellipse cx="0" cy="0" rx="140" ry="105" fill="#facc15" opacity="0.6"/>
          
          <!-- Peel texture dots -->
          <circle cx="-50" cy="-30" r="2" fill="#ca8a04"/>
          <circle cx="60" cy="40" r="2" fill="#ca8a04"/>
          <circle cx="20" cy="-60" r="2" fill="#ca8a04"/>
          <circle cx="-80" cy="40" r="2" fill="#ca8a04"/>
          
          <!-- Defect 1: Oleocellosis Rind Burn Patch -->
          <path d="M 20 -40 Q 60 -70 85 -20 Q 70 20 35 0 Z" fill="#713f12" stroke="#854d0e" stroke-width="2" opacity="0.9"/>
          
          <!-- Defect 2: Mold Spore Spot at Stem Calyx -->
          <circle cx="-150" cy="0" r="16" fill="#14532d" stroke="#16a34a" stroke-width="2"/>
          <circle cx="-150" cy="0" r="6" fill="#f0fdf4"/>
          
          <!-- Stem Button -->
          <circle cx="-160" cy="0" r="8" fill="#4d7c0f"/>
        </g>
        
        <text x="120" y="120" fill="#38bdf8" font-family="monospace" font-size="13" font-weight="bold">VISION STATION: CITRUS_OPTIC_02</text>
      </svg>
    `),
    defaultResult: {
      overallStatus: 'WARN',
      qualityScore: 71.0,
      defectCount: 2,
      summary: 'Export Downgrade: Early green mold (Penicillium digitatum) at stem button and localized oleocellosis rind oil burn.',
      inspectionTimeMs: 11.9,
      defects: [
        {
          id: 'DEF-CIT-01',
          label: 'Stem-End Green Mold',
          confidence: 0.95,
          severity: 'CRITICAL',
          box_2d: [460, 280, 540, 360],
          description: 'Spore mycelium growth around calyx button risking carton-wide rot spread.',
          causeHypothesis: 'Harvest clipping tool contamination or delayed post-harvest fungicidal drenching.',
          actionRecommendation: 'Eject from export carton line; quarantine harvest lot #402.',
        },
        {
          id: 'DEF-CIT-02',
          label: 'Oleocellosis Rind Staining',
          confidence: 0.88,
          severity: 'MINOR',
          box_2d: [380, 520, 480, 620],
          description: 'Ruptured essential oil glands causing oxidized brown epidermal discoloration.',
          causeHypothesis: 'Fruit picked under wet morning turgid conditions.',
          actionRecommendation: 'Downgrade to domestic processing grade.',
        },
      ],
      edgeAction: {
        conveyorRouting: 'DIVERT_REWORK_TRAY',
        strobeTriggerDelayMs: 30,
        suggestedToleranceAdjustment: 'Recalibrate spectral chlorophyll absorption index',
      },
      processedBy: 'gemini-3.8-flash-edge-gateway',
      timestamp: '2026-09-29T08:41:19Z',
    },
  },

  // --- LOGISTICS ---
  {
    id: 'log-carton-01',
    title: 'Corrugated Shipping Carton (Flute Integrity & Seal)',
    domain: 'logistics',
    subCategory: 'Package Integrity & Sortation',
    itemType: 'Double-Wall RSC Shipping Box (400x300x250mm)',
    description: 'High-speed package singulation scanner detecting carton edge buckling, flap opening, and structural collapse.',
    svgDataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600" style="background:#0b1120;">
        <!-- High-speed Roller Belt -->
        <g stroke="#1e293b" stroke-width="6">
          <line x1="50" y1="50" x2="750" y2="50"/>
          <line x1="50" y1="120" x2="750" y2="120"/>
          <line x1="50" y1="190" x2="750" y2="190"/>
          <line x1="50" y1="260" x2="750" y2="260"/>
          <line x1="50" y1="330" x2="750" y2="330"/>
          <line x1="50" y1="400" x2="750" y2="400"/>
          <line x1="50" y1="470" x2="750" y2="470"/>
          <line x1="50" y1="540" x2="750" y2="540"/>
        </g>
        
        <!-- Kraft Cardboard Box Main Face -->
        <rect x="180" y="140" width="440" height="320" rx="8" fill="#c29158" stroke="#926233" stroke-width="4"/>
        
        <!-- Packing Tape Down the Center -->
        <rect x="375" y="140" width="50" height="320" fill="#d97706" opacity="0.85"/>
        
        <!-- Shipping Barcode Label -->
        <g transform="translate(220, 180)">
          <rect width="130" height="90" fill="#ffffff" rx="4" stroke="#94a3b8" stroke-width="1"/>
          <!-- Barcode lines -->
          <rect x="15" y="15" width="4" height="40" fill="#000"/>
          <rect x="23" y="15" width="2" height="40" fill="#000"/>
          <rect x="29" y="15" width="6" height="40" fill="#000"/>
          <rect x="40" y="15" width="3" height="40" fill="#000"/>
          <rect x="47" y="15" width="5" height="40" fill="#000"/>
          <rect x="56" y="15" width="2" height="40" fill="#000"/>
          <rect x="63" y="15" width="7" height="40" fill="#000"/>
          <rect x="74" y="15" width="3" height="40" fill="#000"/>
          <rect x="82" y="15" width="5" height="40" fill="#000"/>
          <rect x="91" y="15" width="4" height="40" fill="#000"/>
          <rect x="100" y="15" width="2" height="40" fill="#000"/>
          <text x="15" y="70" fill="#1e293b" font-family="monospace" font-size="9" font-weight="bold">1Z 999 999 03 12</text>
        </g>
        
        <!-- DEFECT 1: Accordion Corner Crush Buckling on Bottom-Right -->
        <path d="M 540 400 Q 560 440 600 445 L 620 380 Q 580 390 540 400 Z" fill="#784d20" stroke="#ef4444" stroke-width="3"/>
        <path d="M 560 415 L 610 425" stroke="#ef4444" stroke-width="2"/>
        <path d="M 550 430 L 595 440" stroke="#ef4444" stroke-width="2"/>
        
        <!-- DEFECT 2: Tape Flap Detachment / Void -->
        <path d="M 375 140 L 425 140 L 415 190 L 375 170 Z" fill="#b45309" stroke="#f59e0b" stroke-width="2"/>
        <line x1="390" y1="140" x2="410" y2="185" stroke="#ef4444" stroke-width="3" stroke-dasharray="3,3"/>
        
        <text x="50" y="40" fill="#38bdf8" font-family="monospace" font-size="13" font-weight="bold">LOGISTICS INDUCTION SCANNER: HUB_WEST_L01</text>
      </svg>
    `),
    defaultResult: {
      overallStatus: 'FAIL',
      qualityScore: 48.0,
      defectCount: 2,
      summary: 'Package Integrity Critical: Structural flute collapse on lower-right corner and popped central closure tape seal.',
      inspectionTimeMs: 15.1,
      defects: [
        {
          id: 'DEF-LOG-01',
          label: 'Corner Flute Crush',
          confidence: 0.98,
          severity: 'CRITICAL',
          box_2d: [630, 675, 755, 785],
          description: 'Corrugated sidewall buckling exceeding 40mm structural depth threshold, compromising stackability.',
          causeHypothesis: 'Excess top load compression in consolidation cage or drop impact from belt transfer.',
          actionRecommendation: 'Actuate high-speed pneumatic divert arm to Route to Audit/Repack Lane.',
        },
        {
          id: 'DEF-LOG-02',
          label: 'Detached Packing Tape Seal',
          confidence: 0.92,
          severity: 'MAJOR',
          box_2d: [230, 465, 320, 540],
          description: 'Adhesive tape lifted 50mm from top carton flap with internal cavity exposure risk.',
          causeHypothesis: 'Insufficient tape applicator wipe-down roller pressure or dusty box surface.',
          actionRecommendation: 'Route to manual re-taping station #3.',
        },
      ],
      edgeAction: {
        conveyorRouting: 'REJECT_PNEUMATIC_PUSHER',
        strobeTriggerDelayMs: 50,
        suggestedToleranceAdjustment: 'Adjust carton dimension volumetric tolerance by +15mm',
      },
      processedBy: 'gemini-3.8-flash-edge-gateway',
      timestamp: '2026-09-29T08:44:30Z',
    },
  },
  {
    id: 'log-label-02',
    title: 'High-Speed Parcel Thermal Label Integrity',
    domain: 'logistics',
    subCategory: 'Barcode & Routing Compliance',
    itemType: 'Automated Sorter Poly-Mailer',
    description: 'Overhead 2D area-scan camera auditing 1D Code-128 and 2D DataMatrix routing labels at 2.5 m/s belt velocity.',
    svgDataUri: svgToDataUri(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="800" height="600" style="background:#090e17;">
        <!-- Black poly-mailer parcel -->
        <rect x="150" y="100" width="500" height="400" rx="16" fill="#1e2229" stroke="#374151" stroke-width="3"/>
        
        <!-- White Thermal Shipping Label -->
        <rect x="230" y="150" width="340" height="300" rx="6" fill="#ffffff" stroke="#cbd5e1" stroke-width="2"/>
        
        <!-- Carrier Logo Placeholder -->
        <text x="250" y="185" fill="#0f172a" font-family="sans-serif" font-size="20" font-weight="900">GLOBAL EXPRESS</text>
        <line x1="250" y1="195" x2="550" y2="195" stroke="#94a3b8" stroke-width="2"/>
        
        <!-- Destination Sort Code -->
        <text x="250" y="235" fill="#0f172a" font-family="monospace" font-size="26" font-weight="bold">ORD-HUB-902</text>
        <text x="440" y="235" fill="#475569" font-family="monospace" font-size="14">PRIORITY-1</text>
        
        <!-- Scuffed 1D Barcode with tear across lines -->
        <g transform="translate(250, 260)">
          <rect x="0" y="0" width="6" height="60" fill="#000"/>
          <rect x="10" y="0" width="3" height="60" fill="#000"/>
          <rect x="18" y="0" width="8" height="60" fill="#000"/>
          <rect x="30" y="0" width="4" height="60" fill="#000"/>
          <rect x="38" y="0" width="10" height="60" fill="#000"/>
          <rect x="52" y="0" width="5" height="60" fill="#000"/>
          <rect x="62" y="0" width="3" height="60" fill="#000"/>
          <rect x="70" y="0" width="9" height="60" fill="#000"/>
          <rect x="85" y="0" width="4" height="60" fill="#000"/>
          <rect x="94" y="0" width="6" height="60" fill="#000"/>
          <rect x="105" y="0" width="3" height="60" fill="#000"/>
          <rect x="112" y="0" width="8" height="60" fill="#000"/>
          
          <!-- DEFECT: Tear gouge across the barcode lines -->
          <path d="M 20 20 L 70 35 L 50 45 Z" fill="#ffffff" stroke="#ef4444" stroke-width="2"/>
        </g>
        
        <!-- DEFECT: Poly Mailer Puncture Hole in Top-Right Corner -->
        <circle cx="600" cy="140" r="18" fill="#090e17" stroke="#ef4444" stroke-width="3"/>
        <line x1="590" y1="130" x2="610" y2="150" stroke="#f43f5e" stroke-width="2"/>
        
        <text x="35" y="45" fill="#38bdf8" font-family="monospace" font-size="13" font-weight="bold">SORTATION GANTRY CAM_08 [2.5 M/S BELT]</text>
      </svg>
    `),
    defaultResult: {
      overallStatus: 'FAIL',
      qualityScore: 42.0,
      defectCount: 2,
      summary: 'Routing Barcode Unreadable: Laceration across 1D check digits causing automatic optical scanner no-read.',
      inspectionTimeMs: 13.7,
      defects: [
        {
          id: 'DEF-LBL-01',
          label: 'Barcode Laceration / Scuff',
          confidence: 0.99,
          severity: 'CRITICAL',
          box_2d: [420, 310, 540, 480],
          description: 'Missing print segment in carrier tracking barcode, causing decode failure on fixed industrial gantry.',
          causeHypothesis: 'Thermal printhead scratch or friction against conveyor diverter rail.',
          actionRecommendation: 'Send immediately to Manual Exception Chute 5 for label reprint.',
        },
        {
          id: 'DEF-LBL-02',
          label: 'Poly-Mailer Bag Puncture',
          confidence: 0.93,
          severity: 'MAJOR',
          box_2d: [200, 720, 270, 780],
          description: '22mm diameter puncture through weather-proof polyethylene film with content spill risk.',
          causeHypothesis: 'Sharp package protruding from upstream merge chute.',
          actionRecommendation: 'Route to repack table for containment re-bagging.',
        },
      ],
      edgeAction: {
        conveyorRouting: 'DIVERT_REWORK_TRAY',
        strobeTriggerDelayMs: 40,
        suggestedToleranceAdjustment: 'Switch scanner decode mode to omnidirectional reconstruction',
      },
      processedBy: 'gemini-3.8-flash-edge-gateway',
      timestamp: '2026-09-29T08:48:11Z',
    },
  },
];
