import { useState, useEffect } from 'react';
import { DomainType, InspectionResult, SampleSubject, EdgeNode, AuditLogEntry } from './types/inspection';
import { SAMPLE_SUBJECTS } from './data/sampleInspectionSubjects';
import { VisionInspectionViewport } from './components/VisionInspectionViewport';
import { ConveyorSimulationStream } from './components/ConveyorSimulationStream';
import { InspectionDetailPanel } from './components/InspectionDetailPanel';
import { EdgeDeploymentStudio } from './components/EdgeDeploymentStudio';
import { QualityAnalyticsPanel } from './components/QualityAnalyticsPanel';
import { Factory, Wheat, Package, Activity, PlaySquare, BarChart2, Cpu, Zap, RefreshCw, Layers } from 'lucide-react';

export default function App() {
  const [selectedDomain, setSelectedDomain] = useState<DomainType>('manufacturing');
  const [activeTab, setActiveTab] = useState<'inspection' | 'conveyor' | 'analytics' | 'edge'>('inspection');
  
  // Current active sample subject
  const [currentSubject, setCurrentSubject] = useState<SampleSubject>(SAMPLE_SUBJECTS[0]);
  const [customImageSrc, setCustomImageSrc] = useState<string | null>(null);
  const [inspectionResult, setInspectionResult] = useState<InspectionResult | null>(SAMPLE_SUBJECTS[0].defaultResult);
  const [selectedDefectId, setSelectedDefectId] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [strictness, setStrictness] = useState<string>('standard');
  const [strobeFlash, setStrobeFlash] = useState<boolean>(false);

  // Edge telemetry fleet
  const [edgeNodes, setEdgeNodes] = useState<EdgeNode[]>([
    {
      id: 'node-jetson-orin-01',
      name: 'Line 1 SMT Gate - Jetson Orin Nano (40W)',
      status: 'ONLINE',
      temperatureC: 48.2,
      gpuUtilizationPct: 41,
      inferenceLatencyMs: 14.2,
      conveyorSpeedMpm: 24.5,
      inspectedCountToday: 14280,
      fpyPercentage: 98.7,
      ipAddress: '192.168.10.42',
      firmware: 'v2.8.4-edge-rt',
    },
    {
      id: 'node-coral-tpu-02',
      name: 'Packhouse B Sorting - Google Coral Edge TPU',
      status: 'ONLINE',
      temperatureC: 42.1,
      gpuUtilizationPct: 62,
      inferenceLatencyMs: 8.8,
      conveyorSpeedMpm: 45.0,
      inspectedCountToday: 38940,
      fpyPercentage: 94.2,
      ipAddress: '192.168.10.88',
      firmware: 'v1.4.1-coral-lite',
    },
    {
      id: 'node-intel-ipc-03',
      name: 'Logistics Dock 7 - Intel Core i7 IPC-610',
      status: 'ONLINE',
      temperatureC: 51.6,
      gpuUtilizationPct: 35,
      inferenceLatencyMs: 19.5,
      conveyorSpeedMpm: 60.0,
      inspectedCountToday: 21500,
      fpyPercentage: 99.1,
      ipAddress: '192.168.10.104',
      firmware: 'v3.1.0-openvino',
    },
  ]);

  // Initial historical audit logs
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([
    {
      id: 'log-001',
      timestamp: '08:42:15',
      batchId: 'BATCH-SMT-409',
      domain: 'manufacturing',
      subjectTitle: 'SMD Circuit Board REV 4.2',
      decision: 'FAIL',
      qualityScore: 58.0,
      defectCount: 2,
      primaryDefect: 'Solder Bridge Short',
      latencyMs: 14.8,
      routing: 'REJECT_PNEUMATIC_PUSHER',
    },
    {
      id: 'log-002',
      timestamp: '08:41:50',
      batchId: 'BATCH-SMT-408',
      domain: 'manufacturing',
      subjectTitle: 'SMD Circuit Board REV 4.2',
      decision: 'PASS',
      qualityScore: 99.2,
      defectCount: 0,
      latencyMs: 13.9,
      routing: 'PASS_FORWARD',
    },
    {
      id: 'log-003',
      timestamp: '08:40:11',
      batchId: 'BATCH-AG-114',
      domain: 'agriculture',
      subjectTitle: 'Honeycrisp Apples (Lane 2)',
      decision: 'FAIL',
      qualityScore: 52.6,
      defectCount: 2,
      primaryDefect: 'Deep Compression Bruise',
      latencyMs: 12.3,
      routing: 'REJECT_PNEUMATIC_PUSHER',
    },
    {
      id: 'log-004',
      timestamp: '08:38:22',
      batchId: 'BATCH-LOG-802',
      domain: 'logistics',
      subjectTitle: 'Corrugated Shipping Carton',
      decision: 'FAIL',
      qualityScore: 48.0,
      defectCount: 2,
      primaryDefect: 'Corner Flute Crush',
      latencyMs: 15.1,
      routing: 'REJECT_PNEUMATIC_PUSHER',
    },
    {
      id: 'log-005',
      timestamp: '08:36:04',
      batchId: 'BATCH-CNC-045',
      domain: 'manufacturing',
      subjectTitle: 'Aerospace Flange Ti-64',
      decision: 'PASS',
      qualityScore: 97.8,
      defectCount: 0,
      latencyMs: 16.2,
      routing: 'PASS_FORWARD',
    },
  ]);

  // When domain changes, pick the first sample from that domain
  const handleSelectDomain = (domain: DomainType) => {
    setSelectedDomain(domain);
    const domainSamples = SAMPLE_SUBJECTS.filter((s) => s.domain === domain);
    if (domainSamples.length > 0) {
      setCurrentSubject(domainSamples[0]);
      setCustomImageSrc(null);
      setInspectionResult(domainSamples[0].defaultResult);
      setSelectedDefectId(null);
    }
  };

  const handleSelectSubject = (subject: SampleSubject) => {
    setCurrentSubject(subject);
    setCustomImageSrc(null);
    setInspectionResult(subject.defaultResult);
    setSelectedDefectId(null);
  };

  // Run Server-side Gemini AI Vision Inspection
  const handleRunInspection = async () => {
    setIsAnalyzing(true);
    const activeImage = customImageSrc || currentSubject.svgDataUri;

    try {
      const response = await fetch('/api/inspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: activeImage,
          mimeType: activeImage.startsWith('data:image/png')
            ? 'image/png'
            : activeImage.startsWith('data:image/svg')
            ? 'image/svg+xml'
            : 'image/jpeg',
          domain: selectedDomain,
          itemType: currentSubject.itemType,
          strictness,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const data: InspectionResult = await response.json();
      setInspectionResult(data);
      setSelectedDefectId(data.defects?.[0]?.id || null);

      // Append entry to live audit logs
      const newLog: AuditLogEntry = {
        id: 'log-' + Date.now().toString().slice(-4),
        timestamp: new Date().toTimeString().slice(0, 8),
        batchId: `BATCH-${selectedDomain.slice(0, 3).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`,
        domain: selectedDomain,
        subjectTitle: currentSubject.title,
        decision: data.overallStatus,
        qualityScore: data.qualityScore,
        defectCount: data.defectCount,
        primaryDefect: data.defects?.[0]?.label,
        latencyMs: data.inspectionTimeMs,
        routing: data.edgeAction?.conveyorRouting || 'PASS_FORWARD',
      };
      setAuditLogs((prev) => [newLog, ...prev.slice(0, 49)]);
    } catch (err) {
      console.error('Inspection failed:', err);
      // Fallback to local default result
      setInspectionResult(currentSubject.defaultResult);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleUploadImage = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setCustomImageSrc(dataUrl);
      setSelectedDefectId(null);
      // Auto-trigger inspection on newly loaded custom photo
      setTimeout(() => handleRunInspection(), 100);
    };
    reader.readAsDataURL(file);
  };

  const handleCaptureWebcam = (dataUrl: string) => {
    setCustomImageSrc(dataUrl);
    setSelectedDefectId(null);
    setTimeout(() => handleRunInspection(), 100);
  };

  const triggerStrobe = () => {
    setStrobeFlash(true);
    setTimeout(() => setStrobeFlash(false), 100);
  };

  const currentDisplayImage = customImageSrc || currentSubject.svgDataUri;
  const filteredSamples = SAMPLE_SUBJECTS.filter((s) => s.domain === selectedDomain);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Visual Camera Flash Animation */}
      {strobeFlash && (
        <div className="fixed inset-0 z-50 bg-white/40 pointer-events-none transition-opacity duration-75" />
      )}

      {/* Top Bar Contract: [Brand title] - [Nav links] - [Primary actions] */}
      <header className="flex items-center justify-between px-6 py-3.5 border-b border-slate-800 bg-slate-950/95 sticky top-0 z-40">
        {/* Zone 1: Single text element wordmark */}
        <div className="flex items-center gap-2">
          <span className="text-base font-bold tracking-tight text-slate-100 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
            <span>ApexVision Edge QA</span>
          </span>
        </div>

        {/* Zone 2: 4-6 text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-400">
          <button
            onClick={() => setActiveTab('inspection')}
            className={`transition-colors hover:text-slate-100 ${
              activeTab === 'inspection' ? 'text-cyan-400 font-semibold border-b border-cyan-400 pb-0.5' : ''
            }`}
          >
            Vision QA Studio
          </button>
          <button
            onClick={() => setActiveTab('conveyor')}
            className={`transition-colors hover:text-slate-100 ${
              activeTab === 'conveyor' ? 'text-cyan-400 font-semibold border-b border-cyan-400 pb-0.5' : ''
            }`}
          >
            Live Conveyor Stream
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`transition-colors hover:text-slate-100 ${
              activeTab === 'analytics' ? 'text-cyan-400 font-semibold border-b border-cyan-400 pb-0.5' : ''
            }`}
          >
            Quality Analytics & Logs
          </button>
          <button
            onClick={() => setActiveTab('edge')}
            className={`transition-colors hover:text-slate-100 ${
              activeTab === 'edge' ? 'text-cyan-400 font-semibold border-b border-cyan-400 pb-0.5' : ''
            }`}
          >
            Edge Deployment & Fleet
          </button>
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={triggerStrobe}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-800 rounded-lg hover:bg-slate-800 transition-colors"
            title="Manual Optical Strobe Trigger"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>Trigger Strobe</span>
          </button>

          <button
            onClick={handleRunInspection}
            disabled={isAnalyzing}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-medium text-white bg-cyan-600 rounded-lg hover:bg-cyan-500 transition-colors shadow-sm disabled:opacity-50"
          >
            {isAnalyzing ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
            <span>Run Edge Inspection</span>
          </button>
        </div>
      </header>

      {/* Domain Navigation & Preset Strip */}
      <div className="bg-slate-900/90 border-b border-slate-800 px-6 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          {/* Domain Category Selector (Interactive Filter Tabs) */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-lg border border-slate-800 text-xs font-medium">
            <button
              onClick={() => handleSelectDomain('manufacturing')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors ${
                selectedDomain === 'manufacturing'
                  ? 'bg-slate-800 text-cyan-300 shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Factory className="w-3.5 h-3.5" />
              <span>Manufacturing & SMT</span>
            </button>

            <button
              onClick={() => handleSelectDomain('agriculture')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors ${
                selectedDomain === 'agriculture'
                  ? 'bg-slate-800 text-cyan-300 shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Wheat className="w-3.5 h-3.5" />
              <span>Agriculture & Produce</span>
            </button>

            <button
              onClick={() => handleSelectDomain('logistics')}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-colors ${
                selectedDomain === 'logistics'
                  ? 'bg-slate-800 text-cyan-300 shadow-xs'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>Logistics & Sortation</span>
            </button>
          </div>

          {/* Quick Preset Subject Selector */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500 font-mono text-[11px] uppercase flex items-center gap-1">
              <Layers className="w-3 h-3 text-slate-500" />
              <span>Presets:</span>
            </span>
            <div className="flex items-center gap-1.5">
              {filteredSamples.map((subject) => {
                const isSelected = currentSubject.id === subject.id && !customImageSrc;
                return (
                  <button
                    key={subject.id}
                    onClick={() => handleSelectSubject(subject)}
                    className={`px-2.5 py-1 rounded text-xs transition-colors truncate max-w-[200px] ${
                      isSelected
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-medium'
                        : 'bg-slate-950/60 text-slate-400 hover:text-slate-200 border border-slate-800'
                    }`}
                    title={subject.title}
                  >
                    {subject.title.split('(')[0].trim()}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Main Workspace Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6">
        {/* Tab 1: Vision Inspection Studio */}
        {activeTab === 'inspection' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left 7 Columns: Vision Machine Viewport */}
            <div className="lg:col-span-7 space-y-4">
              <VisionInspectionViewport
                imageSrc={currentDisplayImage}
                result={inspectionResult}
                selectedDefectId={selectedDefectId}
                onSelectDefect={setSelectedDefectId}
                isAnalyzing={isAnalyzing}
                onUploadImage={handleUploadImage}
                onCaptureWebcam={handleCaptureWebcam}
              />

              {/* Subject Description Card */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-xs">
                <div className="flex items-center justify-between mb-1.5">
                  <h4 className="font-semibold text-slate-200">{currentSubject.title}</h4>
                  <span className="font-mono text-cyan-400 text-[11px]">
                    {currentSubject.subCategory}
                  </span>
                </div>
                <p className="text-slate-400 leading-relaxed">{currentSubject.description}</p>
              </div>
            </div>

            {/* Right 5 Columns: Inspection Verdict & Defect Detail Panel */}
            <div className="lg:col-span-5">
              <InspectionDetailPanel
                result={inspectionResult}
                selectedDefectId={selectedDefectId}
                onSelectDefect={setSelectedDefectId}
                onRunInspection={handleRunInspection}
                isAnalyzing={isAnalyzing}
                strictness={strictness}
                onChangeStrictness={setStrictness}
              />
            </div>
          </div>
        )}

        {/* Tab 2: Conveyor Belt Live Simulation */}
        {activeTab === 'conveyor' && (
          <div className="space-y-6">
            <ConveyorSimulationStream currentDomain={selectedDomain} />
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-xs">
              <h4 className="font-semibold text-slate-200 mb-1 flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span>Simulated High-Speed Inline Quality Gate Architecture</span>
              </h4>
              <p className="text-slate-400 leading-relaxed">
                As parts traverse the conveyor belt at up to 150 units/min, an optical through-beam sensor triggers the telecentric ring strobe.
                The edge inferencing engine localizes defects within &lt;15ms latency, issuing a high-speed pneumatic pusher command to eject defective units into rework chutes before downstream assembly.
              </p>
            </div>
          </div>
        )}

        {/* Tab 3: Quality Analytics & Logs */}
        {activeTab === 'analytics' && (
          <QualityAnalyticsPanel auditLogs={auditLogs} currentDomain={selectedDomain} />
        )}

        {/* Tab 4: Edge Deployment & Fleet Management */}
        {activeTab === 'edge' && (
          <EdgeDeploymentStudio edgeNodes={edgeNodes} />
        )}
      </main>

      {/* Global Minimal Footer */}
      <footer className="mt-auto border-t border-slate-800 bg-slate-950 px-6 py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>ApexVision Computer Vision Quality Inspection System · Edge Deployment Engine</span>
          <div className="flex items-center gap-4 font-mono text-[11px] text-slate-400">
            <span>MODELS: GEMINI 3.8 FLASH / ONNX TENSORRT</span>
            <span aria-hidden="true">·</span>
            <span>PRECISION: INT8 QUANTIZED</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
