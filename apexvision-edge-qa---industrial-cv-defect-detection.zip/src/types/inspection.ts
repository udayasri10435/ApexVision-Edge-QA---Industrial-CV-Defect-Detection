export type DomainType = 'manufacturing' | 'agriculture' | 'logistics';

export type DefectSeverity = 'CRITICAL' | 'MAJOR' | 'MINOR';

export type InspectionDecision = 'PASS' | 'WARN' | 'FAIL';

export interface DefectItem {
  id: string;
  label: string;
  confidence: number;
  severity: DefectSeverity;
  // Normalized bounding box [ymin, xmin, ymax, xmax] scaled 0 to 1000
  box_2d: [number, number, number, number];
  description: string;
  causeHypothesis?: string;
  actionRecommendation: string;
}

export interface EdgeActionConfig {
  conveyorRouting: 'PASS_FORWARD' | 'REJECT_PNEUMATIC_PUSHER' | 'DIVERT_REWORK_TRAY' | 'HALT_LINE_ALERT';
  strobeTriggerDelayMs: number;
  suggestedToleranceAdjustment: string;
}

export interface InspectionResult {
  overallStatus: InspectionDecision;
  qualityScore: number;
  defectCount: number;
  summary: string;
  inspectionTimeMs: number;
  defects: DefectItem[];
  edgeAction: EdgeActionConfig;
  processedBy?: string;
  timestamp: string;
  warning?: string;
}

export interface SampleSubject {
  id: string;
  title: string;
  domain: DomainType;
  subCategory: string;
  itemType: string;
  description: string;
  svgDataUri: string;
  defaultResult: InspectionResult;
}

export interface EdgeNode {
  id: string;
  name: string;
  status: 'ONLINE' | 'OFFLINE' | 'DEGRADED';
  temperatureC: number;
  gpuUtilizationPct: number;
  inferenceLatencyMs: number;
  conveyorSpeedMpm: number;
  inspectedCountToday: number;
  fpyPercentage: number;
  ipAddress: string;
  firmware: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  batchId: string;
  domain: DomainType;
  subjectTitle: string;
  decision: InspectionDecision;
  qualityScore: number;
  defectCount: number;
  primaryDefect?: string;
  latencyMs: number;
  routing: string;
}
